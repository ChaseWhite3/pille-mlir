# Bench rails (SYNTHETIC)

One bench supply feeds two regulated rails. Both rails are the one regulator design
(`power.rhm`), used twice under names of their own.

supply is a bench supply, whose output voltage is 12 V
rail-5v is a regulator, whose output voltage is 5 V
rail-3v3 is a regulator, whose output voltage is 3.3 V

## Ports

- gnd
- v5
- v3v3

## Connections

- VIN joins supply.out, rail-5v.vin and rail-3v3.vin
- GND joins supply.gnd, rail-5v.gnd, rail-3v3.gnd and gnd
- V5 joins rail-5v.vout and v5
- V3V3 joins rail-3v3.vout and v3v3
