# Using the rails (SYNTHETIC)

The procedure done to the bench a-bench.md says: its things are that page's.

## Steps

- rail-5v is enabled
- enable rail-5v and rail-3v3
- rail-5v is enabled
- rail-5v is disabled
- enable rail-5v whenever convenient
- supply is on
- switch off supply
- switch on supply
