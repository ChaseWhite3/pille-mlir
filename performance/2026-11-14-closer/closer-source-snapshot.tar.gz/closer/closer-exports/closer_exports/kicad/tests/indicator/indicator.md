# Power indicator (SYNTHETIC) (from KiCad)

Imported from `indicator.kicad_sch` by `racket -l- closer_exports/kicad/import_design.rhm indicator.kicad_sch`: each
symbol a thing named by its reference, with its library symbol, footprint, KiCad identity and value under it;
each net a connection; each global label a port. A symbol no model is bound to is a model of its own, its pins
its ports, with nothing said of what flows through it. The page's models are said by the module beside it.

D1 is an LED:
  - symbol: Device:LED
  - footprint: LED_SMD:LED_0603_1608Metric
  - kicad: 3d2232f0-6984-54e8-9eb3-31e1665c4cb8
  - value: Green
J1 is a Connector_Generic:Conn_01x02:
  - symbol: Connector_Generic:Conn_01x02
  - footprint: Connector_PinHeader_2.54mm:PinHeader_1x02_P2.54mm_Vertical
  - kicad: ab8d2077-b6a4-5be2-b56f-0978051bc817
  - value: Conn_01x02
R1 is a resistor, whose resistance is 330 Ω:
  - symbol: Device:R
  - footprint: Resistor_SMD:R_0603_1608Metric
  - kicad: c1af578c-fa50-575c-8b9c-bf7ee5e333db
  - value: 330

## Ports

- vcc
- gnd

## Connections

- LED_A joins D1.anode and R1.b
- GND joins gnd, D1.cathode and J1.pin_2
- VCC joins vcc, J1.pin_1 and R1.a

## Steps

