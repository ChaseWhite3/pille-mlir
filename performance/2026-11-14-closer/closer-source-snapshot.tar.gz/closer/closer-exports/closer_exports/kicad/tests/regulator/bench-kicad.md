# Bench rails, one from KiCad (SYNTHETIC)

The bench of `closer_exports/assembly/tests/bench`, with its 3.3 V rail's design taken from KiCad: the regulator
drawn in `regulator.kicad_sch`, checked to realize the declared regulator before its values are used, then checked
against the 3.3 V the page asks of it. The lines nested under rail-3v3 are written from the design by
`racket -l- closer_exports/kicad/write_materials.rhm bench-kicad.md closer_exports/kicad/tests/regulator/design`;
a line an author adds under a part is kept by the part's KiCad identity. A 100 Ω load hangs on the 5 V rail, and the
3.3 V rail holds a reset line high through an RC of 10 kΩ and 10 µF, so the steps see currents, power and the time
the reset takes.

supply is a bench supply, whose output voltage is 12 V
rail-5v is a regulator, whose output voltage is 5 V
rail-3v3 is a regulator, from regulator.kicad_sch:
  - output voltage: 3.3 V
  - U1 is an adjustable regulator:
    - symbol: Regulator_Linear:LM317_TO-220
    - footprint: Package_TO_SOT_THT:TO-220-3_Vertical
    - kicad: 370aaa52-b606-5b96-9fb2-12e29a19b579
  - R1 is a resistor, whose resistance is 240 Ω:
    - symbol: Device:R
    - footprint: Resistor_SMD:R_0603_1608Metric
    - kicad: 9693d02a-61d1-562a-922a-a1ff6642014a
  - R2 is a resistor, whose resistance is 390 Ω:
    - symbol: Device:R
    - footprint: Resistor_SMD:R_0603_1608Metric
    - kicad: 8417b2d3-e82e-5d72-ad1a-81f089092adf
  - C1 is a capacitor, whose capacitance is 0.1 µF:
    - symbol: Device:C
    - footprint: Capacitor_SMD:C_0603_1608Metric
    - kicad: 7f47e168-7291-507d-8719-d48b8784835e
  - C2 is a capacitor, whose capacitance is 1 µF:
    - symbol: Device:C
    - footprint: Capacitor_SMD:C_0603_1608Metric
    - kicad: 4fb3602d-aba6-5218-9337-60c37b2d6589
  - VIN joins vin, C1.a and U1.vin
  - VOUT joins vout, C2.a, R1.a and U1.vout
  - ADJ joins R1.b, R2.a and U1.adj
  - GND joins gnd, C1.b, C2.b and R2.b
load is a resistor, whose resistance is 100 Ω, whose rating is 0.5 W
reset-r is a resistor, whose resistance is 10 kΩ
reset-c is a capacitor, whose capacitance is 10 µF
reset is a logic input

## Ports

- gnd
- v5
- v3v3

## Connections

- VIN joins supply.out, rail-5v.vin and rail-3v3.vin
- GND joins supply.gnd, rail-5v.gnd, rail-3v3.gnd, load.b, reset-c.b, reset.gnd and gnd
- V5 joins rail-5v.vout, load.a and v5
- V3V3 joins rail-3v3.vout, reset-r.a and v3v3
- RESET joins reset-r.b, reset-c.a and reset.input

## Steps

- V5 is high
- V3V3 is high
- RESET is high
- current of load.a is 51.6 mA
- voltage of VIN between 11.9 V and 12 V
- power of load <= 0.5 W
- switch off supply
- V5 is low
- V3V3 is low
- RESET is low within 500 ms
- rail-3v3.ADJ is low
- switch on supply
- V3V3 is high
- RESET is high within 200 ms
