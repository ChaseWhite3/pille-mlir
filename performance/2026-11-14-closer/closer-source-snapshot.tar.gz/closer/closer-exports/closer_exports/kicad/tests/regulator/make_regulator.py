#!/usr/bin/env python3
"""Write regulator.kicad_sch: the LM317 regulator of closer_exports/assembly/tests/bench/power.rhm drawn as a KiCad
schematic (SYNTHETIC: placed by this script, not drawn by hand), with KiCad's own library symbols copied from an
installed KiCad. Each pin has a label at its connection point: a global label for the circuit's ports (VIN, VOUT,
GND), a local one for the net inside it (ADJ), so KiCad itself makes the nets. Then KiCad's CLI writes what Closer
imports: the netlist, the electrical rules check, and the sheet as SVG.

    python3 make_regulator.py [KICAD_APP]     default ~/Applications/KiCad.app
"""
import os, re, subprocess, sys, uuid

HERE = os.path.dirname(os.path.abspath(__file__))
APP = sys.argv[1] if len(sys.argv) > 1 else os.path.expanduser('~/Applications/KiCad.app')
LIBS = os.path.join(APP, 'Contents/SharedSupport/symbols')
CLI = os.path.join(APP, 'Contents/MacOS/kicad-cli')
NS = uuid.UUID('6f1c2c0e-6d1f-4d44-9b8e-1c0d2a3b4c5d')   # fixed, so the file is the same each time


def uid(*parts):
    return str(uuid.uuid5(NS, '/'.join(parts)))


def library_symbol(lib, name):
    text = open(os.path.join(LIBS, f'{lib}.kicad_sym')).read()
    start = text.index(f'\n\t(symbol "{name}"') + 1
    depth = 0
    for i in range(start, len(text)):
        if text[i] == '(':
            depth += 1
        elif text[i] == ')':
            depth -= 1
            if depth == 0:
                block = text[start:i + 1]
                return block.replace(f'(symbol "{name}"', f'(symbol "{lib}:{name}"', 1)


def pins_of(block):
    return {m.group(3): (float(m.group(1)), float(m.group(2))) for m in
            re.finditer(r'\(pin \w+ \w+\s*\(at ([-\d.]+) ([-\d.]+) \d+\)[\s\S]*?\(number "([^"]*)"', block)}


SYMBOLS = {'Device:R': ('Device', 'R'), 'Device:C': ('Device', 'C'),
           'Regulator_Linear:LM317_TO-220': ('Regulator_Linear', 'LM317_TO-220')}
BLOCKS = {lib_id: library_symbol(*where) for lib_id, where in SYMBOLS.items()}
PINS = {lib_id: pins_of(block) for lib_id, block in BLOCKS.items()}

# reference, library symbol, value, footprint, position (mm, on the 1.27 mm grid), net of each pin
PARTS = [
    ('U1', 'Regulator_Linear:LM317_TO-220', 'LM317_TO-220', 'Package_TO_SOT_THT:TO-220-3_Vertical', (101.6, 76.2),
     {'1': 'ADJ', '2': 'VOUT', '3': 'VIN'}),
    ('R1', 'Device:R', '240', 'Resistor_SMD:R_0603_1608Metric', (116.84, 88.9), {'1': 'VOUT', '2': 'ADJ'}),
    ('R2', 'Device:R', '390', 'Resistor_SMD:R_0603_1608Metric', (116.84, 101.6), {'1': 'ADJ', '2': 'GND'}),
    ('C1', 'Device:C', '100n', 'Capacitor_SMD:C_0603_1608Metric', (86.36, 88.9), {'1': 'VIN', '2': 'GND'}),
    ('C2', 'Device:C', '1u', 'Capacitor_SMD:C_0603_1608Metric', (127.0, 88.9), {'1': 'VOUT', '2': 'GND'}),
]
PORTS = {'VIN': 'input', 'VOUT': 'output', 'GND': 'passive'}   # global labels: the circuit's ports

SHEET = uid('sheet')
FONT = '(effects (font (size 1.27 1.27)))'


def placed(ref, lib_id, value, footprint, at, nets):
    x, y = at
    pins = ''.join(f'\n\t\t(pin "{n}" (uuid "{uid(ref, "pin", n)}"))' for n in PINS[lib_id])
    return f'''	(symbol (lib_id "{lib_id}") (at {x} {y} 0) (unit 1)
		(exclude_from_sim no) (in_bom yes) (on_board yes) (dnp no)
		(uuid "{uid(ref)}")
		(property "Reference" "{ref}" (at {x + 2.54} {y - 1.27} 0) {FONT})
		(property "Value" "{value}" (at {x + 2.54} {y + 1.27} 0) {FONT})
		(property "Footprint" "{footprint}" (at {x} {y} 0) (effects (font (size 1.27 1.27)) (hide yes)))
		(property "Datasheet" "~" (at {x} {y} 0) (effects (font (size 1.27 1.27)) (hide yes))){pins}
		(instances (project "regulator" (path "/{SHEET}" (reference "{ref}") (unit 1))))
	)'''


def labels(ref, lib_id, at, nets):
    out = []
    for number, net in nets.items():
        px, py = PINS[lib_id][number]
        x, y = round(at[0] + px, 2), round(at[1] - py, 2)   # the symbol's y is up, the sheet's down
        if net in PORTS:
            out.append(f'''	(global_label "{net}" (shape {PORTS[net]}) (at {x} {y} 0) (fields_autoplaced yes)
		(effects (font (size 1.27 1.27)) (justify left))
		(uuid "{uid(ref, "label", number)}")
		(property "Intersheetrefs" "${{INTERSHEET_REFS}}" (at {x} {y} 0) (effects (font (size 1.27 1.27)) (hide yes)))
	)''')
        else:
            out.append(f'''	(label "{net}" (at {x} {y} 0) (effects (font (size 1.27 1.27)) (justify left bottom))
		(uuid "{uid(ref, "label", number)}"))''')
    return out


def main():
    body = [f'(kicad_sch (version 20231120) (generator "closer_make_regulator") (generator_version "1")',
            f'	(uuid "{SHEET}")', '	(paper "A5")',
            '	(title_block (title "LM317 regulator (SYNTHETIC)") (comment 1 "closer_exports/assembly/tests/bench/power.rhm"))',
            '	(lib_symbols']
    body += ['\t\t' + BLOCKS[lib_id].replace('\n', '\n\t') for lib_id in BLOCKS]
    body.append('	)')
    for ref, lib_id, value, footprint, at, nets in PARTS:
        body.append(placed(ref, lib_id, value, footprint, at, nets))
        body += labels(ref, lib_id, at, nets)
    body += ['	(sheet_instances (path "/" (page "1")))', ')']
    sch = os.path.join(HERE, 'regulator.kicad_sch')
    open(sch, 'w').write('\n'.join(body) + '\n')
    open(os.path.join(HERE, 'regulator.kicad_pro'), 'w').write('{"meta": {"filename": "regulator.kicad_pro", "version": 1}}\n')
    # the project's library tables, by KiCad's own path variables: the libraries the symbols and footprints name
    sym = ''.join(f'  (lib (name "{lib}")(type "KiCad")(uri "${{KICAD10_SYMBOL_DIR}}/{lib}.kicad_sym")(options "")(descr ""))\n'
                  for lib in sorted({where[0] for where in SYMBOLS.values()}))
    open(os.path.join(HERE, 'sym-lib-table'), 'w').write(f'(sym_lib_table\n  (version 7)\n{sym})\n')
    fps = sorted({fp.split(':')[0] for *_, fp, _, _ in [(p[0], p[1], p[2], p[3], p[4], p[5]) for p in PARTS]})
    fp = ''.join(f'  (lib (name "{lib}")(type "KiCad")(uri "${{KICAD10_FOOTPRINT_DIR}}/{lib}.pretty")(options "")(descr ""))\n'
                 for lib in fps)
    open(os.path.join(HERE, 'fp-lib-table'), 'w').write(f'(fp_lib_table\n  (version 7)\n{fp})\n')
    run = lambda *a: subprocess.run([CLI, *a], check=True, capture_output=True, text=True)
    netlist = os.path.join(HERE, 'regulator.net')
    run('sch', 'export', 'netlist', '--format', 'kicadsexpr', '-o', netlist, sch)
    # the netlist names its source by its absolute path: kept relative, so no checkout's path is recorded
    text = open(netlist).read().replace(f'(source "{sch}")', '(source "regulator.kicad_sch")')
    open(netlist, 'w').write(text)
    erc = subprocess.run([CLI, 'sch', 'erc', '--format', 'json', '--severity-all', '-o', os.path.join(HERE, 'regulator-erc.json'), sch],
                         capture_output=True, text=True)
    run('sch', 'export', 'svg', '--exclude-drawing-sheet', '-o', HERE, sch)
    prl = os.path.join(HERE, 'regulator.kicad_prl')   # KiCad's local preferences, not part of the design
    if os.path.exists(prl):
        os.remove(prl)
    print('wrote', sch, '· ERC exit', erc.returncode, '·', run('version').stdout.strip())


if __name__ == '__main__':
    main()
