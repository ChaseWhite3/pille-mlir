# Kilns on a branch

k-1 is a kiln
k-2 is a kiln, known to be COLD
k-3 is a kiln, known to be HOT

## Steps

- if k-1 is hot, heat k-2
- k-2 is hot
- possibly k-2 is hot
- if k-3 is not hot, cool k-2
- k-2 is cold
- heat k-1
- if k-1 is hot, cool k-2
- k-2 is cold
