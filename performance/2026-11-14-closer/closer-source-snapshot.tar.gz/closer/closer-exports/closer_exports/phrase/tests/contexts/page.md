# Contexts (SYNTHETIC): what a context block binds, and for how long

view-a is a board, also called the North Board.
view-b is a board.
c-1 is a config.
c-2 is a config.
dev-1 is a device.

## Two names of one thing in one context

- In the context of view-a:
  - Add c-1 to the North Board.
  - Add c-1 to view-a.
  - Add c-1 and c-2 to the board.

## Nested, and restored on leaving

- In the context of the North Board:
  - Add c-1 to the board.
  - In the context of view-b:
    - Add c-1 to the board.
    - Add c-2.
  - Add c-2 to the status board.
  - Inspect the board.
- Add c-2 to the board.
- Add c-1.

## Refused rather than absorbed

- In the context of view-a:
  - Add c-2 to dev-1.
  - Add c-2 to the gizmo.
- In the context of the gadget:
  - Add c-1.
