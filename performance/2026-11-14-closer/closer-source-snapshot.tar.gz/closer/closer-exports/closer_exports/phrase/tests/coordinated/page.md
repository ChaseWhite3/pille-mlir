# Coordination (SYNTHETIC): things grouped forward, left to right

alpha is a piston pump known to be idle
bravo is a piston pump known to be idle
charlie is a gear pump known to be idle
bench-1 is a bench

## Steps

- set up alpha and bravo on bench-1
- Set up alpha, bravo and charlie on bench-1.
- release charlie on bench-1
- alpha and bravo is ready
- charlie is not ready
