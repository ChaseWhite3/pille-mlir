# Kilns in sets and contexts

k-1 is a kiln
k-2 is a kiln
the kilns are k-1 and k-2

Kilns cool slowly, so each is heated once.

## Steps

- For each kiln in the kilns:
  - heat the kiln
- In the context of k-1:
  - cool the kiln
- Don't fire a cold kiln.
- k-1 is cold
- k-2 is hot
