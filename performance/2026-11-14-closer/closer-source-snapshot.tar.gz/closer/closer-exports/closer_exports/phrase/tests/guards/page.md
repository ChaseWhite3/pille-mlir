# Guards (SYNTHETIC): a step that happens only where its guard holds

view-a is a board, also called the North Board.
c-1 is a config.
c-2 is a config.

## Steps

- Open view-a.
- With view-a open, add c-1 to view-a.
- Close view-a.
- With view-a open, add c-2 to view-a.
- Check c-1.
- Check c-2.
- In the context of the North Board:
  - Open the board.
  - With the board open, add c-2.
  - Check c-2.
- With view-a ajar, add c-1 to view-a.
