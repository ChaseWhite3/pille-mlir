# Kilns over every run

k-1 is a kiln
k-2 is a kiln, known to be COLD

## Steps

- possibly k-1 is hot
- heat k-2
- necessarily k-2 is hot
- k-2 is hot until k-2 is cold
- eventually k-2 is cold
- cool k-2
- always k-2 is cold
- possibly eventually k-1 is hot
- k-1 is cold
- possibly k-3 is hot
- heat k-1
