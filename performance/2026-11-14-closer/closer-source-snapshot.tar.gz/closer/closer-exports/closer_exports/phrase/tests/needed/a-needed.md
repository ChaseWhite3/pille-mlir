# The kiln a step needs

k-1 is a kiln, known to be COLD
k-2 is a kiln, known to be HOT

## Steps

- cool the kiln
- k-2 is cold
- heat the kiln
- fire the kiln
- heat k-1
- fire the kiln
- the kiln is hot
