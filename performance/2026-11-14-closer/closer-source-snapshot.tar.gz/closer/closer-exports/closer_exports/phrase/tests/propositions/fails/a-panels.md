# Panels, panel-a known inactive

panel-a is a panel, known to be INACTIVE
panel-b is a panel
pump-a is a pump

## Steps

- panel-a is active
- start pump-a
- panel-a is active
