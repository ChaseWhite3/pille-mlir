# Panels, panel-a known active

panel-a is a panel, known to be ACTIVE
panel-b is a panel
pump-a is a pump

## Steps

- panel-a is active
- start pump-a
- panel-a is active
