# Panels and displays

panel-a is a panel, known to be INACTIVE
screen-a is a display, known to be DARK

## Steps

- panel-a is inactive
- screen-a is dark
- mount panel-a
- inspect panel-a
- light screen-a
- panel-a is active
- screen-a is lit
- panel-a is lit
- screen-a is active
