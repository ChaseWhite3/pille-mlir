# Panels and a pump, said by description

panel-a is a panel, known to be ACTIVE
panel-b is a panel
pump-a is a pump, known to be RUNNING

## Steps

- the pump is running
- the panel is active
- pump-a is active
- a panel is active
- the valve is active
- panel-a is purple
- panel-a is active
