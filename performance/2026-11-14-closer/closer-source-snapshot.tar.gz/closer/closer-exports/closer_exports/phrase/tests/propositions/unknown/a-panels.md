# Panels, nothing known of panel-a

panel-a is a panel
panel-b is a panel
pump-a is a pump

## Steps

- panel-a is active
- start pump-a
- panel-a is active
