# Every kiln, some kiln, no kiln

k-1 is a kiln, known to be COLD
k-2 is a kiln, known to be COLD

## Steps

- every kiln is cold
- no kiln is hot
- heat k-1
- every kiln is cold
- some kiln is hot
- no kiln is hot
- heat k-2
- every kiln is hot
