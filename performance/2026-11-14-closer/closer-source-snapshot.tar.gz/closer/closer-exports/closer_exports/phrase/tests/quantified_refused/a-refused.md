# Quantified words where no one thing is meant

k-1 is a kiln, known to be COLD
k-2 is a kiln, known to be COLD

## Steps

- heat every kiln
- if every kiln is cold, heat k-1
- one kiln is hot
- all kilns are cold
- every kiln is cold
