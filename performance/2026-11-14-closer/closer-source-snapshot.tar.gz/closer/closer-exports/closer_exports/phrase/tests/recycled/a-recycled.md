# A cell recycled, then charged

c-1 is a cell, known to be FLAT
c-2 is a cell, known to be FLAT

## Steps

- charge c-1
- drain c-1
- recycle c-1
- charge c-1
- charge c-2
- drain c-2
