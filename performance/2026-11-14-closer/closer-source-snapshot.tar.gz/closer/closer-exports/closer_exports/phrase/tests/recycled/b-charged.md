# A charged cell recycled

c-1 is a cell, known to be CHARGED

## Steps

- recycle c-1
- drain c-1
