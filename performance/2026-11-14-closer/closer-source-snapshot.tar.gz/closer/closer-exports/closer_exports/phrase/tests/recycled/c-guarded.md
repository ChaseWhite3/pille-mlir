# A recycled cell, under a guard

c-1 is a cell, known to be FLAT
c-2 is a cell

## Steps

- recycle c-1
- if c-1 is flat, charge c-1
- charge c-2
- recycle c-2
