# Refusals (SYNTHETIC): steps the phrase space must not read

alpha is a piston pump known to be idle
bench-1 is a bench

## Steps

- polish alpha on bench-1
- set up bench-1 on alpha
- set up the pump on bench-1
- set up gamma on bench-1
- set up alpha on bench-1
