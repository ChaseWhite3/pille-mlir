# A block form a project adds (SYNTHETIC): its body, read N times

view-a is a board.
c-1 is a config.

## Steps

- In the context of view-a:
  - Repeat 3 times:
    - Add c-1.
  - Inspect the board.
- Repeat 2 times:
  - Inspect view-a.
- Repeat several times:
  - Inspect view-a.
