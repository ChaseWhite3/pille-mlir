# Quieted, but slowly

pr-high is an alarm, known to be QUIET
poc is a simulator

## Steps

- cause pr-high on poc
  - takes: 1 s
- measure the latency of pr-high on poc
  - latency: 4 s
  - takes: 4 s
- stop pr-high on poc
  - takes: 3 s
