# Quieted, how long it took not said

pr-high is an alarm, known to be QUIET
poc is a simulator

## Steps

- cause pr-high on poc
- stop pr-high on poc
