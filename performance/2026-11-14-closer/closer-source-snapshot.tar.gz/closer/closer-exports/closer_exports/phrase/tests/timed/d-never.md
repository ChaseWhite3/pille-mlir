# Never quieted

pr-high is an alarm, known to be QUIET
poc is a simulator

## Steps

- cause pr-high on poc
  - takes: 1 s
