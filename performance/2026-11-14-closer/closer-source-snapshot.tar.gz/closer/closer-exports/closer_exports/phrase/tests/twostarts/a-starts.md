# A start said two ways

k-1 is a kiln, known to be COLD
k-1 is a kiln, known to be HOT
k-2 is a kiln, known to be COLD

## Steps

- heat k-1
- k-1 is hot
- heat k-2
- k-2 is hot
