# An unless of two conditions

## Steps

- unless k-3 is hot and k-1 is hot, heat k-2
- k-2 is cold
- unless k-3 is hot and k-2 is hot, heat k-2
- k-2 is hot
