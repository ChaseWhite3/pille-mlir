# A line the language does not read

## Steps

- polish k-2
- k-2 is hot
