# The first kiln alone

k-1 is a kiln, known to be COLD

## Steps

- heat k-1
- cool k-1
- heat k-2
- k-2 is hot
