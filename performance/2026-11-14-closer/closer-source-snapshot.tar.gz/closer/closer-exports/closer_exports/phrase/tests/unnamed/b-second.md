# The second kiln, named here

k-2 is a kiln, known to be COLD

## Steps

- heat k-2
- cool k-2
