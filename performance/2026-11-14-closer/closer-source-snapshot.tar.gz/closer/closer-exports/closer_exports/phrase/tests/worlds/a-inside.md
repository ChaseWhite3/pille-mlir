# A kiln fired inside the world its heating opens

k-1 is a kiln, known to be COLD
k-2 is a kiln, known to be COLD

## Steps

- heat k-1
  - fire k-1
  - k-1 is hot
  - cool k-1
- cool k-1
