# Worlds inside worlds

k-1 is a kiln, known to be COLD
k-2 is a kiln, known to be COLD

## Steps

- heat k-1
- cool k-1
- heat k-2
  - fire k-2
  - heat k-1
    - fire k-1
    - cool k-2
    - cool k-1
  - k-2 is hot
- cool k-2
- cool k-1
