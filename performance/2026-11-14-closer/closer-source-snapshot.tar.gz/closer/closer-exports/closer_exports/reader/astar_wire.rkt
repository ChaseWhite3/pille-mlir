#lang racket/base

(require (only-in ffi/unsafe malloc memcpy ptr-add)
         (only-in ffi2 cpointer->ptr_t)
         "../../../closer-lang/json.rkt")

(provide read_batch)

;; Each frame contains a sentence count and, per sentence, UTF-8 token
;; metadata and a score block. All lengths and score fields are little-endian.
(define (read_batch)
  (define (read-block size)
    (define data (read-bytes size))
    (unless (and (bytes? data) (= (bytes-length data) size))
      (error 'astar "truncated binary request"))
    data)
  (define header (read-bytes 4))
  (cond
    [(eof-object? header) #f]
    [else
     (unless (= (bytes-length header) 4)
       (error 'astar "truncated binary frame header"))
     (define frame (read-block (integer-bytes->integer header #f #f)))
     (define position 0)
     (define (take size)
       (define start position)
       (set! position (+ position size))
       (when (> position (bytes-length frame))
         (error 'astar "truncated binary score block"))
       start)
     (define (integer32 signed?)
       (define start (take 4))
       (integer-bytes->integer frame signed? #f start position))
     (define (u32) (integer32 #f))
     (define (f32)
       (define start (take 4))
       (floating-point-bytes->real frame #f start position))
     (define (buffer count)
       (define size (* count 4))
       (define start (take size))
       (define result (malloc (max 4 size) 'atomic-interior))
       (cond
         [(system-big-endian?)
          (define swapped (make-bytes size))
          (for* ([i (in-range 0 size 4)] [j (in-range 4)])
            (bytes-set! swapped (+ i j) (bytes-ref frame (+ start i (- 3 j)))))
          (memcpy result swapped size)]
         [else (memcpy result (ptr-add frame start) size)])
       (cpointer->ptr_t result))
     (define batch
       (for/list ([i (in-range (u32))])
         (define token-size (u32))
         (define token-start (take token-size))
         (define tokens (parse_json (bytes->string/utf-8 frame #f token-start position)))
         (define n (u32))
         (cons tokens
               (and (positive? n)
                    (let* ([nbest (u32)] [keep (integer32 #t)] [steps (u32)]
                           [leaf-out (f32)] [penalty (f32)] [leaves (u32)]
                           [width (add1 n)])
                      (vector n nbest keep steps leaf-out penalty leaves
                              (buffer (* 2 leaves)) (buffer leaves) (buffer (* n width))
                              (buffer n) (buffer (* width width)) (buffer (* width width))))))))
     (unless (= position (bytes-length frame))
       (error 'astar "trailing bytes in binary request"))
     batch]))
