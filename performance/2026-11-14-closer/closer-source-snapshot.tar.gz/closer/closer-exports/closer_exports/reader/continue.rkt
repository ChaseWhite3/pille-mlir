#lang racket/base
;; What may come next in a line, by its categories: the chart of the words so far, and the entries of the lexicon
;; that continue it (closer_exports/next_words, the editor's next-words). The categories and their combination are
;; models/ccg_model.rkt's: forward and backward application, an NP slot taking things of its kind or a kind under it,
;; and linear coordination of noun phrases. A prefix is not yet a step, so one more rule joins its pieces: what a
;; functor still takes may begin with the next phrase, X/Y then Y/Z is X/Z (forward composition), as a marker starts
;; the noun phrase a verb waits for ("cause pr-high" then "on"). Every complete continuation is still a reading of the
;; model's: the checks hold each to its `parses`. Meanings are not combined here; what an entry does is its own.
(require racket/list racket/match racket/string racket/treelist)
(provide continuations offers spanning category-text gloss combine-categories parameterize-parents)

;; Rhombus lists (treelists) and pairs as plain Racket lists, all the way down.
(define (plain v)
  (cond [(treelist? v) (map plain (treelist->list v))]
        [(pair? v) (cons (plain (car v)) (plain (cdr v)))]
        [else v]))

(define current-parents (make-parameter (hash)))
(define (fits? kind wanted)
  (let climb ([at kind] [seen '()])
    (cond [(equal? at wanted) #t]
          [(member at seen) #f]
          [else (for/or ([up (in-list (hash-ref (current-parents) at '()))]) (climb up (cons at seen)))])))

;; An argument a category takes: Y of X/Y, where `arg` would do. What is said of things of the kinds ks (PROP\NP[ks],
;; from a subject already said) takes what is said of things of a kind they all are.
(define (takes? wanted arg)
  (match* (wanted arg)
    [(`(NP ,k) `(NP . ,ks)) (andmap (lambda (x) (fits? x k)) ks)]
    [(`(,o \\ (NP . ,ks)) `(,o \\ (NP ,k))) (andmap (lambda (x) (fits? x k)) ks)]
    [(_ _) (equal? wanted arg)]))

;; X/Y composed into what follows: where its innermost result (peeling its own arguments, last first) is a Y, that
;; result is X instead; #f where it is not. X/Y then (Y/Z1)/Z2 is (X/Z1)/Z2, as a guard ("if … ,": S/S) begins the
;; step after it.
(define (composed out in right)
  (match right
    [`(,mid / ,z) (cond [(takes? in mid) `(,out / ,z)]
                        [(composed out in mid) => (lambda (inner) `(,inner / ,z))]
                        [else #f])]
    [_ #f]))

;; What two adjacent categories make, by the model's rules and prefix composition: a list of categories.
(define (combine left right)
  (append
   (match left [`(,out / ,in) #:when (takes? in right) (list out)] [_ '()])
   (match right [`(,out \\ ,in) #:when (takes? in left) (list out)] [_ '()])
   ;; coordination, binary: NP then "and" is NP waiting for an NP; that then an NP is one NP of all their things
   (match* (left right)
     [(`(NP . ,ks) (or 'CONJ 'COMMA)) (list `(NP-AND . ,ks))]
     [(`(NP-AND . ,ks) `(NP . ,more)) (list `(NP ,@ks ,@more))]
     [(_ _) '()])
   ;; forward composition, for a prefix: X/Y then Y/Z is X/Z, and deeper (composed)
   (match left
     [`(,out / ,in) (let ([c (composed out in right)]) (if c (list c) '()))]
     [_ '()])
   ;; a claim's subject begins the claim: X/PROP then NP is X waiting for what is said of the NP ("if" then "c-1")
   (match* (left right)
     [(`(,out / PROP) `(NP . ,ks)) (list `(,out / (PROP \\ (NP ,@ks))))]
     [(_ _) '()])
   ;; a subject before what takes it and then more: Y then (X\Y)/Z is X/Z ("the latency of pr-high" then "is within")
   (match right
     [`((,out \\ ,in) / ,z) #:when (takes? in left) (list `(,out / ,z))]
     [_ '()])))

;; The entries of the lexicon that match the tokens at a place: [entry ...], each (words category meaning).
(define (at-place entries tokens i)
  (for/list ([e (in-list entries)]
             #:when (let ([ws (first e)])
                      (and (pair? ws) (<= (+ i (length ws)) (length tokens))
                           (equal? ws (take (drop tokens i) (length ws))))))
    e))

;; Every category over all of the tokens: what the words so far are.
(define (spanning tokens* entries* parents*)
  (define tokens (plain tokens*))
  (define entries (plain entries*))
  (parameterize ([current-parents (for/hash ([p (in-list (plain parents*))]) (values (car p) (cdr p)))])
    (span tokens entries)))

(define (span tokens entries)
  (define n (length tokens))
  (define chart (make-hash))
  (define (cell i j) (hash-ref chart (cons i j) '()))
  (define (add! i j c) (unless (member c (cell i j)) (hash-set! chart (cons i j) (cons c (cell i j)))))
  (for ([i (in-range n)])
    (for ([e (in-list (at-place entries tokens i))])
      (add! i (+ i (length (first e))) (second e))))
  (for* ([width (in-range 2 (add1 n))] [i (in-range (add1 (- n width)))])
    (define j (+ i width))
    (for* ([k (in-range (add1 i) j)] [a (in-list (cell i k))] [b (in-list (cell k j))] [c (in-list (combine a b))])
      (add! i j c)))
  (if (zero? n) '() (reverse (cell 0 n))))

;; A category as Mojo's chart spells it: (S/PP[on-DeviceSimulator])/NP[Alarm].
(define (local id) (let ([s (format "~a" id)]) (last (string-split s "#"))))
(define (category-text c)
  (match c
    [`(,out / ,in) (string-append (wrapped out) "/" (wrapped in))]
    [`(,out \\ ,in) (string-append (wrapped out) "\\" (wrapped in))]
    [`(NP ,k) (format "NP[~a]" (local k))]
    [`(NP . ,ks) (format "NP[~a]" (string-join (map local ks) ","))]
    [`(NP-AND . ,ks) (format "NP[~a] and" (string-join (map local ks) ","))]
    [`(PP ,w ,k) (format "PP[~a-~a]" (string-replace (format "~a" w) " " "-") (local k))]
    [`(STATE ,k) (format "STATE[~a]" (local k))]
    [`(MEAS ,k) (format "MEAS[~a]" (local k))]
    [`(W ,w) (format "W[~a]" w)]
    [_ (format "~a" c)]))
(define (wrapped c) (match c [`(,_ ,(or '/ '\\) ,_) (string-append "(" (category-text c) ")")] [_ (category-text c)]))

;; What a category still to be said is, in words (Mojo's argument_said): NP[Alarm] an alarm, PP[on-X] on an x.
(define (article word) (if (regexp-match? #rx"^[aeiou]" word) "an " "a "))
(define (said c)
  (match c
    [`(NP ,k) (let ([w (string-downcase (local k))]) (string-append (article w) w))]
    [`(NP . ,_) "some things"]
    [`(PP ,w ,k) (string-append (format "~a" w) " " (said `(NP ,k)))]
    [`(STATE ,_) "a state"]
    ['PROP "a claim"]
    ['MEASURE "a quantity"]
    ['RANGE "a range"]
    [`(MEAS ,k) (string-append "the quantity of " (said `(NP ,k)))]
    [`(W ,w) (format "~a" w)]
    ['COMMA "a comma"]
    ['CONJ "and"]
    ['S "a step"]
    [`(PROP \\ ,_) "what is said of it"]
    [_ (category-text c)]))
;; What a phrase does when it comes next, by what the words become with it (Mojo's gloss_next).
(define (gloss c)
  (match c
    ['S "finishes the step"]
    ['PROP "finishes the claim"]
    [`(,_ ,(or '/ '\\) ,_)
     (string-append "then " (string-join (let loop ([c c]) (match c [`(,out ,(or '/ '\\) ,in) (cons (said in) (loop out))] [_ '()])) ", then "))]
    [_ (string-append "then " (said c))]))

;; The entries that continue the tokens: [(entry made) ...], each entry with the category the words become with it,
;; in the lexicon's order. With no tokens, every entry continues, as itself.
(define (continuations tokens* entries* parents*)
  (define tokens (plain tokens*))
  (define entries (plain entries*))
  (define n (length tokens))
  (parameterize ([current-parents (for/hash ([p (in-list (plain parents*))]) (values (car p) (cdr p)))])
    ;; the roots of the words before the last k, each k once
    (define roots (let ([memo (make-hash)]) (lambda (k) (hash-ref! memo k (lambda () (span (take tokens (- n k)) entries))))))
    (define (made-after k category)
      (if (= k n)
          category
          (for*/first ([r (in-list (roots k))] [c (in-list (combine r category))]) c)))
    (append
     (for*/list ([e (in-list entries)] [made (in-value (made-after 0 (second e)))] #:when made)
       (list e made))
     ;; an entry the last words begin ("pr-high is" then "sounding" of "is sounding"): the rest of its words, with
     ;; what the words before it become with it whole
     (for*/list ([e (in-list entries)]
                 [ws (in-value (first e))]
                 [k (in-range 1 (min (length ws) (add1 n)))]
                 #:when (equal? (take ws k) (drop tokens (- n k)))
                 [made (in-value (made-after k (second e)))]
                 #:when made)
       (list (list (drop ws k) (second e) (third e)) made)))))

;; The continuations as the editor offers them: [(phrase category gloss complete operation) ...], the phrase the
;; entry's words, the category the words become with it, whether that finishes a step or a claim, and the operation
;; the entry is a wording of (#f for a name, a marker, a word); an entry whose phrase is the last token is no offer.
(define (operation-of meaning) (match meaning [`(call ,o . ,_) o] [_ #f]))
(define (offers tokens* entries* parents*)
  (define tokens (plain tokens*))
  (define last-token (and (pair? tokens) (last tokens)))
  (for/fold ([made '()] [seen '()] #:result (reverse made))
            ([pair (in-list (continuations tokens* entries* parents*))])
    (match-define (list (list words _ meaning) category) pair)
    (define phrase (string-join words " "))
    (if (or (member phrase seen) (equal? phrase last-token))
        (values made seen)
        (values (cons (list phrase (category-text category) (gloss category) (and (memq category '(S PROP)) #t)
                            (operation-of meaning))
                      made)
                (cons phrase seen)))))

;; The rules above for another chart (reader/derive.rkt): what two categories make, under the kinds' parents.
(define (combine-categories left right) (combine left right))
(define (parameterize-parents parents thunk)
  (parameterize ([current-parents (for/hash ([p (in-list (plain parents))]) (values (car p) (cdr p)))]) (thunk)))
