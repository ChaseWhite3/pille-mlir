#lang racket/base
;; A line's derivation, as the editor's structure view draws it (closer derivation, and the record's readings'
;; `syntax`): the parse of the line kept as a tree, each node its category, the rule that made it, the words it
;; covers, its children, its meaning, and what of an operation's roles it has filled and with which words.
;;
;; As Rhombus keeps a parse as nested syntax over the reader's token tree, the chart here keeps every item's
;; backpointers, and the tree is read off them. The categories combine as closer_exports/reader/continue.rkt combines
;; them, and the meanings by models/ccg_model.rkt's own `applied` and `conjoined`, so a whole line's tree means what
;; the model's reduction does. A prefix's composition (">B") and a subject that begins a claim carry the functor's
;; meaning: what fits is said by the categories.
(require racket/list racket/match racket/string racket/treelist json
         "continue.rkt"
         "../../../models/ccg_model.rkt")
(provide derivation-json)

(define (plain v)
  (cond [(treelist? v) (map plain (treelist->list v))]
        [(pair? v) (cons (plain (car v)) (plain (cdr v)))]
        [else v]))

;; An item: its category, meaning, and node: (rule start end children phrase entry-words sources), sources the words
;; that filled each role so far, ((role phrase start end) ...).
(struct item (category meaning rule start end children phrase sources) #:transparent)

(define (local id) (last (string-split (format "~a" id) "#")))

;; What the meanings of two items make by a rule, or #f.
(define (meaning-of rule functor argument)
  (case rule
    [(">" "<") (let ([m (applied (item-meaning functor) (item-meaning argument))]) (and m (not (eq? m #f)) m))]
    [else (item-meaning functor)]))

;; The role an application fills: the functor's next waiting role, where its meaning is a call.
(define (next-role meaning)
  (match meaning [`(call ,_ (,r . ,_) ,_) #:when (not (equal? r "")) r] [_ #f]))

;; The words a role is filled with: the argument, or within it the item its meaning came from whole, as a marker
;; passes on the noun phrase after it ("on poc": poc).
(define (source-of it)
  (or (for/first ([c (in-list (item-children it))] #:when (equal? (item-meaning c) (item-meaning it))) (source-of c))
      it))

(define (joined-items rule category functor argument left right)
  (define m (meaning-of rule functor argument))
  (and (or m (member rule '(">B" "&" "S")))
       (let* ([role (and (member rule '(">" "<")) (next-role (item-meaning functor)))]
              [sources (append (item-sources functor)
                               (if role
                                   (let ([from (source-of argument)])
                                     (list (list role (item-phrase from) (item-start from) (item-end from))))
                                   '()))])
         (item category (or m (item-meaning functor)) rule (item-start left) (item-end right) (list left right)
               (string-append (item-phrase left) " " (item-phrase right)) sources))))

;; Every way two adjacent items combine: [item ...].
(define (combined left right)
  (define lc (item-category left))
  (define rc (item-category right))
  (filter values
   (for/list ([c (in-list (combine-categories lc rc))])
     (define rule
       (cond [(and (pair? lc) (equal? (cadr lc) '/) (equal? (car lc) c)) ">"]
             [(and (pair? rc) (equal? (cadr rc) '\\) (equal? (car rc) c)) "<"]
             [(and (pair? c) (memq (car c) '(NP NP-AND))) "&"]
             [else ">B"]))
     (case rule
       [(">") (joined-items ">" c left right left right)]
       [("<") (joined-items "<" c right left left right)]
       [("&") (if (eq? (car c) 'NP-AND)
                  (item c (item-meaning left) "&" (item-start left) (item-end right) (list left right)
                        (string-append (item-phrase left) " " (item-phrase right)) '())
                  (item c (conjoined (item-meaning left) (item-meaning right)) "&" (item-start left) (item-end right)
                        (list left right) (string-append (item-phrase left) " " (item-phrase right)) '()))]
       [else (joined-items ">B" c left right left right)]))))

;; The chart: cell (i . j) → items, the first way each category came to be kept.
(define (chart-of tokens entries)
  (define n (length tokens))
  (define chart (make-hash))
  (define (cell i j) (hash-ref chart (cons i j) '()))
  (define (add! i j it)
    (unless (for/or ([o (in-list (cell i j))]) (and (equal? (item-category o) (item-category it))
                                                     (equal? (item-meaning o) (item-meaning it))))
      (hash-set! chart (cons i j) (append (cell i j) (list it)))))
  (for ([i (in-range n)])
    (for ([e (in-list entries)])
      (define ws (first e))
      (when (and (pair? ws) (<= (+ i (length ws)) n) (equal? ws (take (drop tokens i) (length ws))))
        (add! i (+ i (length ws)) (item (second e) (third e) "LEX" i (+ i (length ws)) '() (string-join ws " ") '())))))
  (for* ([width (in-range 2 (add1 n))] [i (in-range (add1 (- n width)))])
    (define j (+ i width))
    (for* ([k (in-range (add1 i) j)] [a (in-list (cell i k))] [b (in-list (cell k j))] [c (in-list (combined a b))])
      (add! i j c)))
  cell)

;; A meaning as a term a person reads: a thing by its name, a call by its operation and its roles, filled or not.
(define (term m)
  (match m
    [`(thing ,n) (format "~a" n)]
    [`(and . ,vs) (string-join (map term vs) " and ")]
    [`(call ,o ,waiting ,filled)
     (string-append "(" (local o)
                    (apply string-append
                           (append (for/list ([f (in-list filled)]) (format " ~a=~a" (first f) (term (second f))))
                                   (for/list ([r (in-list waiting)] #:unless (equal? r "")) (format " ~a=?" r))))
                    ")")]
    [(? symbol?) (symbol->string m)]
    [_ (format "~s" m)]))

;; The arguments a category still takes, nearest first: [{position, direction, category}].
(define (needs-of c)
  (let loop ([c c] [acc '()])
    (match c
      [`(,out / ,in) (loop out (cons (cons "right" in) acc))]
      [`(,out \\ ,in) (loop out (cons (cons "left" in) acc))]
      [_ (for/list ([n (in-list (reverse acc))] [i (in-naturals 1)])
           (hasheq 'position i 'direction (car n) 'category (category-text (cdr n))))])))

;; A node as the structure view reads it. kinds: operation's local name → ((role canonical-kind) ...).
(define (node-json it kinds)
  (define m (item-meaning it))
  (define calls
    (match m
      [`(call ,o ,waiting ,filled)
       (define roles (hash-ref kinds (local o) '()))
       (list (hasheq 'operation (local o)
                     'roles (for/list ([r (in-list roles)] [i (in-naturals)])
                              (define name (first r))
                              (define source (assoc name (item-sources it)))
                              (define waiting-at (index-of (filter (lambda (w) (not (equal? w ""))) waiting) name))
                              (hasheq 'index i 'name name 'type (second r)
                                      'status (if waiting-at "waiting" "supplied")
                                      'bindings (if waiting-at (list (add1 waiting-at)) '())
                                      'sources (if source
                                                   (list (hasheq 'phrase (second source) 'start (third source) 'end (fourth source)))
                                                   '())))))]
      [_ '()]))
  (define rule (item-rule it))
  (define text (category-text (item-category it)))
  (for/fold ([h (hasheq 'category text 'display-category text 'rule rule
                        'kind (case rule [("LEX") "lexical"] [(">" "<") "application"] [("&") "coordination"] [else "composition"])
                        'start (item-start it) 'end (item-end it) 'phrase (item-phrase it) 'term (term m)
                        'children (for/list ([c (in-list (item-children it))]) (node-json c kinds))
                        'alignment (hasheq 'needs (needs-of (item-category it)) 'calls calls 'rule rule))])
            ([kv (in-list (match m [`(call ,o . ,_) (list (cons 'operation (local o)))] [_ '()]))])
    (hash-set h (car kv) (cdr kv))))

;; The derivation of a line's tokens, as JSON: {complete, pieces, uncovered, words}. Complete where some item over
;; every word is a step or a claim, its tree the one piece; else the longest pieces from the left, and each word no
;; piece starts at.
(define (derivation-json tokens* entries* parents* kinds*)
  (define tokens (plain tokens*))
  (define entries (plain entries*))
  ;; by the operation's local name: a read of a copy of the pages names its operations where the copy is
  (define kinds (for/hash ([k (in-list (plain kinds*))]) (values (local (first k)) (second k))))
  (define n (length tokens))
  (parameterize-parents (plain parents*)
    (lambda ()
      (define cell (chart-of tokens entries))
      (define whole (and (> n 0) (for/first ([it (in-list (cell 0 n))] #:when (memq (item-category it) '(S PROP))) it)))
      (define-values (pieces uncovered)
        (if whole
            (values (list whole) '())
            (let loop ([i 0] [pieces '()] [uncovered '()])
              (if (>= i n)
                  (values (reverse pieces) (reverse uncovered))
                  (let ([found (for*/first ([j (in-range n i -1)] [it (in-list (cell i j))]) it)])
                    (if found
                        (loop (item-end found) (cons found pieces) uncovered)
                        (loop (add1 i) pieces (cons (hasheq 'word (list-ref tokens i) 'at i) uncovered))))))))
      (jsexpr->string
       (hasheq 'complete (and whole #t)
               'pieces (for/list ([p (in-list pieces)]) (node-json p kinds))
               'uncovered uncovered
               'words n)))))
