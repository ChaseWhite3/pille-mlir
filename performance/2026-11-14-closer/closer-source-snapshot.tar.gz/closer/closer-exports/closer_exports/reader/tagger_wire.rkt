#lang racket/base

(require racket/file racket/port
         (only-in ffi/unsafe malloc memcpy ptr-add)
         (only-in ffi2 cpointer->ptr_t ptr_t->cpointer))

(provide read_model read_features write_scores)

;; All model and request blocks are little-endian 32-bit values. Copy into
;; aligned, GC-managed storage before passing them to hosted Pille.
(define (aligned data [start 0] [size (- (bytes-length data) start)])
  (define result (malloc (max 4 size) 'atomic-interior))
  (cond
    [(system-big-endian?)
     (define swapped (make-bytes size))
     (for* ([i (in-range 0 size 4)] [j (in-range 4)])
       (bytes-set! swapped (+ i j) (bytes-ref data (+ start i (- 3 j)))))
     (memcpy result swapped size)]
    [else (memcpy result (ptr-add data start) size)])
  (cpointer->ptr_t result))

(define (read_model path)
  (define data (file->bytes path))
  (unless (and (>= (bytes-length data) 164)
               (= (integer-bytes->integer data #f #f 0 4) 40)
               (zero? (modulo (bytes-length data) 4)))
    (error 'tagger "invalid packed model"))
  (vector (aligned data 164 (- (bytes-length data) 164)) (aligned data 4 160)))

(define (read_features)
  (define header (read-bytes 4))
  (cond
    [(eof-object? header) #f]
    [else
     (unless (= (bytes-length header) 4) (error 'tagger "truncated frame header"))
     (define size (integer-bytes->integer header #f #f))
     (define data (read-bytes size))
     (unless (and (bytes? data) (= (bytes-length data) size) (>= size 4))
       (error 'tagger "truncated features"))
     (define position 4)
     (define count (integer-bytes->integer data #f #f 0 4))
     (define requests
       (for/list ([i (in-range count)])
         (unless (<= (+ position 4) size) (error 'tagger "missing sentence length"))
         (define length (integer-bytes->integer data #f #f position (+ position 4)))
         (set! position (+ position 4))
         (unless (and (<= 2 length 252) (<= (+ position (* length 36)) size))
           (error 'tagger "invalid sentence length or feature block"))
         (define features (aligned data position (* length 36)))
         (set! position (+ position (* length 36)))
         (vector length features)))
     (unless (= position size) (error 'tagger "trailing feature bytes"))
     requests]))

(define (write_scores length tags deps)
  (define n (- length 2))
  (for ([pointer (in-list (list tags deps))]
        [count (in-list (list (* n 425) (* n (+ n 1))))])
    (define data (make-bytes (* count 4)))
    (memcpy data (ptr_t->cpointer pointer) (bytes-length data))
    (when (system-big-endian?)
      (for ([i (in-range 0 (bytes-length data) 4)])
        (define word (subbytes data i (+ i 4)))
        (for ([j (in-range 4)])
          (bytes-set! data (+ i j) (bytes-ref word (- 3 j))))))
    (write-bytes data)))
