"""Record what the parser's Python and NumPy side gives, for the Rhombus and Pille port to be held to.

    PYTHON record_vectors.py CHECKOUT > vectors.json        (a Python with NumPy)

This is a reference recorder, run once while the Python annotator (mojo/reading/tagger/annotator.py) and the request
builder (mojo/reading/pille_decoder.py) still stand; nothing at run time reads it. The sentences are the public ones
(the readings records under examples/ and mojo's fixtures, in order of first appearance) and the tokenizer's hard
lines from annotator_check.py. For each: the annotator's analyses (text, space after, norm, tag, coarse part of
speech, morphology, lemma), the tagger's six feature ids, the supertagger's feature ids, and, for the public ones,
the SHA-256 of the packed search request with its leaves and the parser's readings.
"""
import glob, hashlib, json, sys
from pathlib import Path


def main(argv):
    root = Path(argv[1]).resolve()
    for folder in ("mojo/reading/tagger", "mojo/reading", "mojo/language"):
        sys.path.insert(0, str(root / folder))
    import annotator, annotator_check
    from pille_native import Parser, pack_batch
    public = []
    for f in sorted(glob.glob(str(root / "examples/**/readings.json"), recursive=True) + glob.glob(str(root / "mojo/**/fixtures/**/readings.json"), recursive=True)):
        public += [s for s in json.loads(Path(f).read_text()) if s not in public]
    parser = Parser(nbest=3)
    try:
        a = parser.annotator
        out = []
        for sentence, parsed in [(s, True) for s in public] + [(s, False) for s in annotator_check.HARD]:
            text = " ".join(sentence.split(" "))
            tokens = a.tokenizer(text)
            row = {"sentence": sentence, "analyses": a.analyses(text),
                   "ids": [[str(v) for v in r] for r in a.tagger.features(a.tokenizer, tokens).tolist()] if tokens else []}
            words = [t.text for t in tokens]
            if words:
                w, s, p = parser.tagger.features(words)
                row["features"] = {"words": w.tolist(), "suffixes": s.tolist(), "prefixes": p.tolist()}
            if parsed and 0 < len(words) <= parser.config["max_length"]:
                annotated = a([sentence])[0]
                tags, deps = parser.tagger.predict([words], batchsize=1)[0]
                request = parser.prepare(annotated, tags, deps)
                packed = pack_batch([annotated], [request])
                row["request"] = {"sha256": hashlib.sha256(packed).hexdigest(), "leaves": [int(v) for v in request["leaves"]],
                                  "leaf_scores": [float(v) for v in request["leaf_scores"]], "leaf_out": request["leaf_out"]}
            if parsed:
                row["readings"] = parser.parse([sentence])[sentence]
            out.append(row)
    finally:
        parser.close()
    json.dump({"schema": "closer-parser-reference/1", "config": parser.config, "vectors": out}, sys.stdout, ensure_ascii=False, indent=0)


if __name__ == "__main__":
    main(sys.argv)
