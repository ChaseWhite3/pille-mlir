"""The screens a recipe drives, through Playwright (closer_exports/run/screen.rhm asks this; it was
mojo/language/browsers.py, and needs no Closer or Mojo module).

A screen is a thing the page's Materials name, at its address, in a browser on a Playwright server (- playwright
server: ws://localhost:3000/) or launched headless here when it names none (- browser: chromium, firefox or
webkit). An Electron app is a thing whose lines say its executable (- executable: …/MacOS/Shop, - arguments: …): it
is launched by Playwright's Electron support, which is Node's alone, through the side-car beside this module
(electron_sidecar.js) on the Node and Playwright that Python's Playwright carries; its window is then driven as any
page, and its menu, its file dialogs and a script in its main process through the side-car. A control is found by
Playwright's own selectors: #id, [name=…], xpath=…, text=Words.

A browser lives as long as the process that opened it, and each step of a run, and each line tried alone, is a call
of its own; so the browsers are kept by a side-car, this module run as `python browsers.py serve PORT`, which the
first call starts and later calls find by side-car.json in the state folder (~/.anote/closer-browsers, or the one
CLOSER_BROWSERS names). It holds each thing's page, one call at a time, so a step drives the screen the step above
left.

    python browsers.py act     one request, JSON on standard input: {name, properties, op, selector, text, patience}
    python browsers.py stop    the side-car ended, and with it every browser it held

Each answers one line of JSON: {"ok": true, "value": …} or {"ok": false, "error": …}.
"""
import json
import os
import socket
import subprocess
import sys
import time
import urllib.error
import urllib.request

STATE = os.environ.get("CLOSER_BROWSERS") or os.path.expanduser("~/.anote/closer-browsers")
ELECTRON_SIDE_CAR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "electron_sidecar.js")
SIDE_CAR = os.path.join(STATE, "side-car.json")


# ── the side-car ─────────────────────────────────────────────────────────────────────────────────────────────────

def serve(port):
    from http.server import BaseHTTPRequestHandler, HTTPServer
    from playwright.sync_api import sync_playwright, Error as PlaywrightError

    playwright = sync_playwright().start()
    open_things = {}   # name → {"browser", "context", "page", "where"}

    def browser_for(properties):
        server = (properties.get("playwright server") or "").strip()
        kind = (properties.get("browser") or "chromium").strip().lower()
        kind = "chromium" if kind in ("chrome", "chromium") else kind
        launcher = getattr(playwright, kind, None)
        if launcher is None:
            raise LookupError(f"Playwright has no browser {kind}: chromium, firefox or webkit")
        if server and server.lower() != "none":
            return launcher.connect(server), server
        try:
            return launcher.launch(headless=True), "headless " + kind + " here"
        except PlaywrightError as e:
            raise LookupError(f"no {kind} to launch here ({str(e).splitlines()[0]}): say a playwright server on the thing's "
                              "Materials line (- playwright server: ws://localhost:3000/), or run playwright install " + kind)

    class ElectronApp:
        """An Electron app launched by the electron module's Node side-car, its window reached over DevTools."""
        def __init__(self, properties):
            import shlex
            import playwright as package
            driver = os.path.join(os.path.dirname(package.__file__), "driver")
            node = os.path.join(driver, "node")
            self.process = subprocess.Popen([node, ELECTRON_SIDE_CAR, "--playwright", os.path.join(driver, "package")],
                                            stdin=subprocess.PIPE, stdout=subprocess.PIPE, text=True, bufsize=1)
            self.next_id = 0
            project = properties.get("_project") or os.getcwd()
            executable = properties["executable"]
            if not os.path.isabs(executable):
                executable = os.path.join(project, executable)
            launched = self.ask("launch", {"executable": executable, "args": shlex.split(properties.get("arguments") or ""), "cwd": project})
            self.cdp = launched["cdp"]

        def ask(self, method, params=None):
            self.next_id += 1
            self.process.stdin.write(json.dumps({"id": self.next_id, "method": method, "params": params or {}}) + "\n")
            self.process.stdin.flush()
            line = self.process.stdout.readline()
            if not line:
                raise LookupError("the Electron side-car ended: " + (self.process.stderr.read() if self.process.stderr else ""))
            answer = json.loads(line)
            if "error" in answer:
                raise LookupError(answer["error"])
            return answer["result"]

        def close(self):
            try:
                self.ask("close")
            finally:
                self.process.stdin.close()
                self.process.wait(timeout=15)

    def electron_page(browser, deadline):
        # the app's first window, once it has one
        while True:
            for context in browser.contexts:
                for page in context.pages:
                    return page
            if time.time() > deadline:
                raise LookupError("the app opened no window")
            time.sleep(0.2)

    def page_of(name, properties, make):
        had = open_things.get(name)
        if had:
            try:
                had["page"].title()
                return had["page"]
            except PlaywrightError:
                open_things.pop(name, None)
        if not make:
            raise LookupError(f"{name} has no page open: a step above opens it")
        if properties.get("executable"):
            app = ElectronApp(properties)
            browser = playwright.chromium.connect_over_cdp(app.cdp)
            page = electron_page(browser, time.time() + 30)
            open_things[name] = {"browser": browser, "context": None, "page": page, "where": "Electron " + properties["executable"], "app": app}
            return page
        browser, where = browser_for(properties)
        context = browser.new_context(ignore_https_errors=True)
        page = context.new_page()
        open_things[name] = {"browser": browser, "context": context, "page": page, "where": where}
        return page

    def act(fields):
        name, op = fields["name"], fields["op"]
        properties = fields.get("properties") or {}
        selector, text = fields.get("selector") or "", fields.get("text") or ""
        patience = float(fields.get("patience") or 20) * 1000
        if op == "close":
            had = open_things.pop(name, None)
            if had:
                if had.get("app"):
                    had["browser"].close()
                    had["app"].close()
                else:
                    had["context"].close()
                    had["browser"].close()
            return "closed"
        if op in ("menu", "dialog", "evaluate", "windows"):
            # what only an Electron app's main process does: its menu, its file dialogs, a script there, its windows
            page_of(name, properties, False)
            app = open_things[name].get("app")
            if app is None:
                raise LookupError(f"{name} is a web page, not an Electron app: it has no {op}")
            if op == "menu":
                return app.ask("click-menu", {"path": selector})["clicked"]
            if op == "dialog":
                return ", ".join(app.ask("answer-file-dialog", {"paths": [p.strip() for p in text.split(",") if p.strip()]})["paths"])
            if op == "evaluate":
                return json.dumps(app.ask("evaluate", {"script": text})["value"])
            return " | ".join(w["title"] for w in app.ask("windows")["windows"])
        if op == "status":
            return [{"name": n, "where": t["where"], "url": t["page"].url} for n, t in open_things.items()]
        if op == "open" and properties.get("executable") and name in open_things:
            # an Electron app opened again is launched again: what a run before left of it is not this run's
            had = open_things.pop(name)
            try:
                had["browser"].close()
                had["app"].close()
            except Exception:
                pass
        page = page_of(name, properties, op == "open")
        page.set_default_timeout(patience)
        if op == "open":
            if selector:
                page.goto(selector)
            return page.title()
        if op == "title":
            return page.title()
        if op == "url":
            return page.url
        if op == "screenshot":
            os.makedirs(os.path.dirname(os.path.abspath(text)), exist_ok=True)
            page.screenshot(path=text)
            return text
        found = page.locator(selector)
        if op == "present":
            return "yes" if found.count() > 0 else ""
        if op == "visible":
            try:
                found.first.wait_for(state="visible", timeout=patience)
                return "yes"
            except PlaywrightError:
                return ""
        if op == "click":
            found.first.click()
            return "clicked"
        if op == "type":
            found.first.fill(text)
            return "typed"
        if op == "text":
            return found.first.inner_text().strip()
        if op == "choose":
            found.first.select_option(label=text)
            return "chosen"
        raise LookupError(f"no page action {op}")

    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *args):
            pass

        def do_POST(self):
            fields = json.loads(self.rfile.read(int(self.headers.get("Content-Length", 0))).decode())
            try:
                answer = {"ok": True, "value": act(fields)}
            except Exception as e:
                answer = {"ok": False, "error": str(e).splitlines()[0] if str(e) else type(e).__name__}
            data = json.dumps(answer).encode()
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)

    server = HTTPServer(("127.0.0.1", port), Handler)
    os.makedirs(STATE, exist_ok=True)
    with open(SIDE_CAR, "w") as f:
        json.dump({"pid": os.getpid(), "port": port, "code": os.path.getmtime(os.path.abspath(__file__))}, f)
    try:
        server.serve_forever()
    finally:
        playwright.stop()


# ── calling it ───────────────────────────────────────────────────────────────────────────────────────────────────

def _alive(port):
    try:
        with socket.create_connection(("127.0.0.1", int(port)), timeout=0.3):
            return True
    except OSError:
        return False


def _clean():
    # the environment for a Python of its own: the calling process's PYTHONHOME (Mojo's) would make it another's
    return {k: v for k, v in os.environ.items() if k not in ("PYTHONHOME", "PYTHONPATH", "PYTHONEXECUTABLE")}


def _python():
    """A Python with Playwright in it: ANOTE_BROWSERS_PYTHON when set, else this one's, Mojo's, or the path's."""
    import shutil
    candidates = [os.environ.get("ANOTE_BROWSERS_PYTHON"), os.path.join(sys.prefix, "bin", "python3"),
                  os.path.expanduser("~/.mojo-venv/bin/python3"), sys.executable, shutil.which("python3")]
    for python in candidates:
        if python and os.path.exists(python):
            if subprocess.run([python, "-c", "import playwright"], capture_output=True, env=_clean()).returncode == 0:
                return python
    raise RuntimeError("no Python here has Playwright: pip install playwright, the version of the Playwright server "
                       "(1.63.0 for the checkout's container), or set ANOTE_BROWSERS_PYTHON to one that has it")


def _recorded(port):
    try:
        with open(SIDE_CAR) as f:
            return json.load(f).get("port") == port
    except (OSError, ValueError):
        return False


def _side_car():
    if os.path.exists(SIDE_CAR):
        with open(SIDE_CAR) as f:
            had = json.load(f)
        if _alive(had["port"]) and had.get("code") == os.path.getmtime(os.path.abspath(__file__)):
            return had["port"]
        if _alive(had["port"]):
            # the side-car runs code older than this: ended, and started again on the code now
            stop()
            time.sleep(0.5)
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        port = s.getsockname()[1]
    os.makedirs(STATE, exist_ok=True)
    log = open(os.path.join(STATE, "side-car.log"), "w")
    python = _python()
    subprocess.Popen([python, os.path.abspath(__file__), "serve", str(port)], stdout=log, stderr=subprocess.STDOUT,
                     stdin=subprocess.DEVNULL, start_new_session=True, env=_clean())
    deadline = time.time() + 30
    while time.time() < deadline:
        # started: its port answers and it has said so in side-car.json. Returning on the port alone lets the next
        # call, made before the file is written, find no side-car and start a second, leaving this one unowned.
        if _alive(port) and _recorded(port):
            return port
        time.sleep(0.1)
    with open(os.path.join(STATE, "side-car.log")) as f:
        raise RuntimeError("the browsers' side-car did not start: " + f.read()[-1500:])


def act(name, properties, op, selector, text, patience):
    """One thing done on the thing's page: open (selector is the address), click, type, choose (an option by its
    words), text, present, visible, title, url, screenshot (text is the file the PNG is written to), close."""
    try:
        port = _side_car()
        body = json.dumps({"name": name, "properties": properties, "op": op, "selector": selector,
                           "text": text, "patience": patience}).encode()
        request = urllib.request.Request(f"http://127.0.0.1:{port}/", data=body, method="POST", headers={"Content-Type": "application/json"})
        with urllib.request.urlopen(request, timeout=float(patience or 20) + 120) as response:
            return response.read().decode()
    except Exception as e:
        return json.dumps({"ok": False, "error": str(e)})


def stop():
    """The side-car ended, and with it every browser it held."""
    if os.path.exists(SIDE_CAR):
        with open(SIDE_CAR) as f:
            had = json.load(f)
        try:
            os.kill(int(had["pid"]), 15)
        except OSError:
            pass
        os.unlink(SIDE_CAR)
    return json.dumps({"ok": True, "value": "stopped"})


if __name__ == "__main__":
    if len(sys.argv) > 2 and sys.argv[1] == "serve":
        serve(int(sys.argv[2]))
    elif len(sys.argv) > 1 and sys.argv[1] == "act":
        asked = json.loads(sys.stdin.readline())
        print(act(asked["name"], asked.get("properties") or {}, asked["op"], asked.get("selector") or "", asked.get("text") or "",
                  asked.get("patience") or "20"))
    elif len(sys.argv) > 1 and sys.argv[1] == "stop":
        print(stop())
    else:
        print(json.dumps({"ok": False, "error": "browsers.py act | stop | serve PORT"}))
