"""A step's dialogue, run as a terminal (closer_exports/run/dialogue.rhm asks this; it was
mojo/language/machines.py's `converse`).

Racket has no pseudo-terminal, and a prompting command needs one, so this one piece of the runner is Python: the
standard library only, no Closer module. It reads one request on standard input,

    {"argv": [...], "environment": {NAME: VALUE}, "secrets": [...], "dialogue": [[SYMBOL, TEXT], ...],
     "live": false, "seconds": 120}

runs argv on a pseudo-terminal, and walks the dialogue's lines: each prompt (?) waited for and answered with the
reply under it (>), a reply read from the environment ([env NAME]) typed and never shown, [enter] an empty line,
each line the command must print (!) waited for, and the end (. with what it must have printed by then, or
nothing). A reply the page leaves to the person ([ask]) fails here: nobody is watching a run that is not live.

Each piece is said as it happens, a line of JSON on standard output ({"piece": {"kind", "text"}}), and the last
line is the answer: {"done": {"exit_code", "output", "ok", "failure"}}. A secret is scrubbed from all of it.
"""
import json
import os
import pty
import re
import select
import sys
import time


def main():
    request = json.loads(sys.stdin.readline())
    argv = request["argv"]
    env = dict(os.environ)
    env.update(request.get("environment") or {})
    secrets = [s for s in (request.get("secrets") or []) if s]
    lines = [(str(s), str(t)) for s, t in request["dialogue"]]
    seconds = float(request.get("seconds") or 120)

    def scrub(text):
        for secret in secrets:
            text = text.replace(secret, "********")
        return text

    def emit(kind, text):
        sys.stdout.write(json.dumps({"piece": {"kind": kind, "text": scrub(text)}}) + "\n")
        sys.stdout.flush()

    pid, fd = pty.fork()
    if pid == 0:
        try:
            os.execvpe(argv[0], argv, env)
        finally:
            os._exit(127)
    state = {"buffer": "", "seen": ""}

    def pump(timeout):
        ready, _, _ = select.select([fd], [], [], timeout)
        if not ready:
            return True
        try:
            chunk = os.read(fd, 4096)
        except OSError:
            chunk = b""
        if not chunk:
            return False
        text = chunk.decode(errors="replace")
        state["buffer"] += text
        state["seen"] += text
        emit("output", text)
        return True

    def wait_for(pattern):
        want = " ".join(pattern.lower().split())
        deadline = time.time() + seconds
        while time.time() < deadline:
            if want in " ".join(state["buffer"].lower().split()):
                # what is after the match is still to be read by the next line of the dialogue
                at = state["buffer"].lower().find(pattern.lower())
                state["buffer"] = state["buffer"][at + len(pattern):] if at >= 0 else ""
                return True
            if not pump(0.25):
                return want in " ".join(state["buffer"].lower().split())
        return False

    def finish(failure):
        if failure:
            emit("failure", failure)
            try:
                os.kill(pid, 9)
            except OSError:
                pass
        while pump(1.0):
            pass
        os.close(fd)
        _, status = os.waitpid(pid, 0)
        code = os.waitstatus_to_exitcode(status)
        emit("end", f"exit {code}")
        output = scrub(state["seen"].replace("\r\n", "\n"))
        sys.stdout.write(json.dumps({"done": {"exit_code": code, "output": output, "ok": not failure and code == 0,
                                              "failure": failure or ("" if code == 0 else f"the command exited {code}")}}) + "\n")
        sys.stdout.flush()

    asked = ""
    for symbol, text in lines:
        if symbol == "$":
            continue
        if symbol == "?":
            if not wait_for(text):
                return finish(f"never asked “{text}”")
            asked = text
            emit("prompt", text)
        elif symbol == ">":
            secret = re.fullmatch(r"\[env ([A-Za-z_][A-Za-z0-9_]*)\]", text.strip())
            if text.strip().lower() == "[ask]":
                return finish(f"the page leaves the answer to “{asked}” to the person, and nobody is watching")
            if secret:
                value = os.environ.get(secret.group(1))
                if value is None:
                    return finish(f"the answer to “{asked}” is read from {secret.group(1)}, which is not set")
                secrets.append(value)
                os.write(fd, (value + "\n").encode())
                emit("sent", text.strip())
            else:
                said = "" if text.strip().lower() in ("[enter]", "") else text.strip()
                os.write(fd, (said + "\n").encode())
                emit("sent", said)
        elif symbol == "!":
            if not wait_for(text):
                return finish(f"never printed “{text}”")
            emit("prompt", text)
        elif symbol == ".":
            if text.strip() and not wait_for(text.strip()):
                return finish(f"never printed “{text.strip()}”")
    return finish("")


if __name__ == "__main__":
    main()
