# Far (SYNTHETIC)

box-9 is a box, at 10.0.0.9:2222, as admin, with key /keys/far, trusting any host key
box-8 is a box at far.example, as root, with password from CLOSER_FAR_PASSWORD
box-1 is a box

## Steps

- greet box-9
- greet box-8
- provision box-8
- stock box-9
- greet box-1
