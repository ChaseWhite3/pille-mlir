# Lab (SYNTHETIC)

box-1 is a box:
  - greeting: hi

## Steps

- greet box-1
- warm box-1
- box-1 is warm
- inspect box-1
- strain box-1
- polish box-1
- launch box-1
- record the command on box-1
  - command: printf 'mode = <box-1:greeting>\nsize = 3\n'
- verify the setting is the expected value in the output
  - setting: mode, expected value: hi
  - setting: size, expected value: 3
