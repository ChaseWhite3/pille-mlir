# Running the lab (SYNTHETIC)

box-2 is a box:
  - greeting: hey

## Steps

- greet box-2
- warm box-2
- polish box-2
- record the command on box-2
  - command: printf 'mode = <box-2:greeting>\nsize = 3\n'
- verify the setting is the expected value in the output
  - setting: mode, expected value: hey
  - setting: size, expected value: 3
- inspect box-2
