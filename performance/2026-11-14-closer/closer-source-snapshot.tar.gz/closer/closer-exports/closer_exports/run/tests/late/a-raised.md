# Raised and stopped (SYNTHETIC)

pr-high is an alarm, known to be QUIET
pr-low is an alarm, known to be QUIET

## Steps

- raise pr-high
  - takes: 1 s
- stop pr-high
  - takes: 2 s
