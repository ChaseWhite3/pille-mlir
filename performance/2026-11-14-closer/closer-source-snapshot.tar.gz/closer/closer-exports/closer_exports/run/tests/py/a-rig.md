# Rig (SYNTHETIC)

rig-1 is a rig, known to be OFF
rig-2 is a rig, known to be OFF

## Steps

- power on rig-1
- power on rig-2
- count rig-1
- announce rig-1
- hail rig-2
- check rig-1
- jam rig-2
