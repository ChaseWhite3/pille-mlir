"""SYNTHETIC: a rig's words in Python, for the runner's Python implementations (closer/python, closer/python_run)."""
from dataclasses import dataclass
from enum import Enum

from anote import Effect, lifecycle, note, noun, verb


class Power(Enum):
    OFF = "off"
    ON = "on"


@noun("rig")
@lifecycle(Power, initial="OFF")
@dataclass(frozen=True)
class Rig:
    name: str


powered = []   # the module's own state: it outlives a step


@verb("power on {rig}", effects=(Effect("rig", requires=("OFF",), produces="ON"),))
def power_on(rig: Rig) -> str:
    note("powering " + rig.name)
    powered.append(rig.name)
    return rig.name + " is on"


@verb("tally {rig}")
def tally(rig: Rig) -> int:
    return len(powered)


@verb("jam {rig}")
def jam(rig: Rig) -> str:
    raise RuntimeError(rig.name + " is jammed")


@verb("weigh {rig} at {grams}")
def weigh(rig: Rig, grams: int) -> str:
    return rig.name + " weighs " + str(grams)
