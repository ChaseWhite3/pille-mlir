# Shop (SYNTHETIC)

corner is a shop, at ADDRESS:
  - browser: chromium
  - patience: 2

## Steps

- visit corner
- order tea at corner
- reorder at corner
- leave corner
- haggle at corner
