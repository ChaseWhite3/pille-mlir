# Bench (SYNTHETIC)

poc is a simulator:
  - program: stand_in_sim.py
  - arguments: --quiet
  - port: PORT
  - alarm key: POCAlarm
  - value key: POCValue

## Steps

- start poc
- raise the alarm on poc
- dim poc
- clear the alarm on poc
- stop poc
- confuse poc
