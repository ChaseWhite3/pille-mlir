"""A stand-in device simulator, as the team's are: launched with its arguments and the port it listens on,
it stays up, takes a message over HTTP as typed at a terminal (POCAlarm=SpO2High POCValue=100), keeps the
state the message put it in, and answers OK, or ERR when a key is not one it knows."""
import sys
from http.server import BaseHTTPRequestHandler, HTTPServer

port = int(sys.argv[-1])
known = {"POCAlarm", "POCValue", "Mode"}
state = {}


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *args):
        pass

    def do_POST(self):
        body = self.rfile.read(int(self.headers.get("Content-Length", 0))).decode()
        for pair in body.split():
            key, _, value = pair.partition("=")
            if key not in known:
                return self.answer("ERR unknown key " + key)
            state[key] = value.strip('"')
        self.answer("OK " + " ".join(f"{k}={v}" for k, v in state.items()))

    def answer(self, text):
        data = text.encode()
        self.send_response(200)
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)


print("stand-in sim listening on", port, "with", sys.argv[1:-1], flush=True)
HTTPServer(("127.0.0.1", port), Handler).serve_forever()
