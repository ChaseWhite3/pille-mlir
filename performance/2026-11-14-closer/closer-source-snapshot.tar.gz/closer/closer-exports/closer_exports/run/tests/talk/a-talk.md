# Talk (SYNTHETIC)

box-1 is a box, known to be LOCKED
note-1 is a note

## Steps

- unlock box-1
  $ sh PROMPTER
  ? Continue?
  > y
  ? Token:
  > [env CLOSER_TALK_TOKEN]
  ! token accepted
- greet box-1
  $ sh PROMPTER
  ? continue?
  > y
  ? Token:
  > lab-0042
  . token accepted (lab-0042)
- unlock box-1
- file note-1
  $ echo hi
- unlock box-1
  $ sh PROMPTER
  ? Continue?
  > n
  ? Token:
  > never
