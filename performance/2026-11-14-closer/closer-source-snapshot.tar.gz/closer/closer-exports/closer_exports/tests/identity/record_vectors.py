"""Records the identity vectors closer_exports/snapshot_check.rhm holds Rhombus to (vectors.json, beside this).

Python is the reference here and nothing of Closer is imported: each rule is written out as its receiver computes
it (hashlib and json alone), over sealed files of this repository, which are read and never written. Run it again
only when a sealed input is added:

    python3 closer-exports/closer_exports/tests/identity/record_vectors.py
"""
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[3]


def canonical(x):
    return json.dumps(x, sort_keys=True, ensure_ascii=False, separators=(",", ":"), allow_nan=False)


def default(x):
    return json.dumps(x, sort_keys=True, allow_nan=False)


def sha(text):
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def without(record, fields):
    return {k: v for k, v in record.items() if k not in fields}


# numbers as the two forms write them: the shortest digits, an exponent under 1e-4 and from 1e16, each sign and
# width; and text outside ASCII, over the basic plane, and control characters
VALUES = [3.0, 0.0, -0.0, 6.0, 1e-07, 1.5e-07, 1e16, 1e22, 1.5e300, 0.1, 0.30000000000000004, 123456789.12345678,
          5e-324, 1e15, 9999999999999998.0, 0.0001, 0.00001, -1.9565194845199585, -8.28385066986084, 1e21, 2.5e-05,
          1234567890123456789.0, 1.7976931348623157e308, 2.2250738585072014e-308, 100.0, 12.5, -0.001, 7, -7, 0,
          2 ** 63, "plain", "café “quoted”", "\U0001d49c over the plane", "tab\tline\nquote\" back\\ del\x7f bell\x07",
          True, False, None, [], {}, [1, 2.5, "x"], {"b": 1.0, "a": [0.5, {"z": None}]}]

# sealed records with floats (a reader's scores) and without: read here, never written
FILES = [
    ("refinement-capture/1", "examples/requirement-evidence/package-2026-11-07-r5/graphs/as-declared/refinement.json"),
    ("refinement-capture/1", "examples/requirement-evidence/package-2026-11-07-r5/graphs/stale/refinement.json"),
    ("refinement-capture/1", "examples/requirement-evidence/package-2026-11-07-r5/graphs/proposed/refinement.json"),
    ("refinement-capture/1", "examples/requirement-evidence/package-2026-11-07-r5/projects/as-declared/readings.json"),
    ("refinement-capture/1", "examples/door-delay/package-2026-11-07-r2/graph/refinement.json"),
    # a language record as Closer in Mojo wrote it of examples/rhombus-meanings (2026-11-12), kept here since that
    # folder's records are rebuilt; its own `digest` is the identity
    ("language-record/1", "closer-exports/closer_exports/tests/identity/language-ir.rhombus-meanings.json"),
    ("language-record/1", "examples/requirement-evidence/package-2026-11-07-r5/projects/as-declared/readings.json"),
]

RULES = {"refinement-capture/1": (["capture"], canonical, 0, ""),
         "language-record/1": (["digest", "generated", "revision"], default, 16, ""),
         "receiving-capture/1": (["id"], default, 20, "cap:")}


def identity(policy, record):
    fields, form, take, prefix = RULES[policy]
    digest = sha(form(without(record, fields)))
    return prefix + (digest if take == 0 else digest[:take])


def floats_in(x):
    if isinstance(x, float):
        return 1
    if isinstance(x, dict):
        return sum(floats_in(v) for v in x.values())
    if isinstance(x, list):
        return sum(floats_in(v) for v in x)
    return 0


out = {"says": "identity vectors recorded by record_vectors.py: Python's own text and digests, the reference",
       "values": [{"value": v, "canonical": canonical(v), "default": default(v)} for v in VALUES],
       "files": []}
for policy, path in FILES:
    record = json.loads((ROOT / path).read_text())
    entry = {"policy": policy, "file": path, "file_sha256": hashlib.sha256((ROOT / path).read_bytes()).hexdigest(),
             "floats": floats_in(record), "identity": identity(policy, record)}
    # what the record says of itself, where it says it under this policy
    if policy == "refinement-capture/1" and isinstance(record.get("capture"), dict):
        entry["recorded"] = record["capture"].get("sha256")
    if policy == "language-record/1" and "digest" in record:
        entry["recorded"] = record["digest"]
    out["files"].append(entry)
# a receiving capture as its validator identifies it
body = {"schema": "closer.capture", "version": 1, "pages": "p", "score": -1.9565194845199585, "name": "café"}
out["receiving"] = {"body": body, "identity": identity("receiving-capture/1", body)}
(HERE / "vectors.json").write_text(json.dumps(out, indent=1, ensure_ascii=False) + "\n")
print(len(out["values"]), "values,", len(out["files"]), "files:", [(f["file"].split("/")[-1], f["floats"], f.get("recorded") == f["identity"] if "recorded" in f else "no recorded id") for f in out["files"]])
