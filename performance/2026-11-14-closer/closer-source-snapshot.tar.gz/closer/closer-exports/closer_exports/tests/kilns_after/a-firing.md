# Firing (SYNTHETIC)

k-1 is a kiln, also called the big kiln
k-2 is a kiln
shelf-a is a shelf
the kilns are k-1 and k-2

## Steps

- load shelf-a into k-1
- heat k-1
- fire the big kiln
- k-1 is hot
- cool k-1
- For each kiln in the kilns:
  - heat the kiln
- k-2 is hot
