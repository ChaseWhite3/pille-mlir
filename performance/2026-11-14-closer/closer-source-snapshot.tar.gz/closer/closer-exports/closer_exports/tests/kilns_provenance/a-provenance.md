# How each role comes by its thing (SYNTHETIC)

k-1 is a kiln, also called the big kiln
k-2 is a kiln
shelf-a is a shelf
the kilns are k-1 and k-2

## Steps

- heat k-1
- fire the big kiln
- load the shelf into k-2
- cool the kiln
- fire the kiln
- For each kiln in the kilns:
  - heat the kiln
