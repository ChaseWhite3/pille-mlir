# Firing, with lines to ask about (SYNTHETIC)

k-1 is a kiln, also called the big kiln
k-2 is a kiln
shelf-a is a shelf

## Steps

- load shelf-a into k-1
- heat k-1
- fire the big kiln
- Verify that the big kiln and k-2 are hot
- Verify there is a shelf in k-1
- Kiln log
- cool k-1
