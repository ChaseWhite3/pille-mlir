"""The sentence pairs Closer's own pipeline makes of a pages folder: its capture (mojo/exports/capture.py, which runs
build/mojo/closer compile) and each occurrence's roles as examples/semantic-slice/runs/2026-11-05/receiving/
make_package.py makes them. For closer_exports' checks, which hold the pairs made in Rhombus to these.

    python3 mojo_pairs.py CHECKOUT PAGES OUT.json
"""
import json, sys

checkout, pages, out = sys.argv[1:4]
sys.path.insert(0, checkout + "/mojo/exports")
import capture as CAP  # noqa: E402

cap = CAP.capture(pages, {})
pairs = []
for o in cap["occurrences"]:
    line = cap["sources"][o["file"]]["text"].split("\n")[o["line"] - 1]
    roles = []
    for r in o["reading"]["roles"]:
        at = line.find(r["phrase"]) if r.get("phrase") else -1
        roles.append({"role": r["role"], "phrase": r.get("phrase"), "span": [at, at + len(r["phrase"])] if at >= 0 else None,
                      "thing": r["label"], "kind": r["kind"]})
    pairs.append({"occurrence": o["id"], "sentence": o["sentence"],
                  "meaning": (o["reading"].get("semantic") or {}).get("meaning") or o["reading"]["operation"],
                  "roles": roles})
with open(out, "w") as f:
    json.dump(pairs, f)
