# Materials (SYNTHETIC): three pumps in two subkinds, a bench, the selected set

alpha is a piston pump known to be idle, whose model is P100, whose configuration is standard
bravo is a piston pump known to be idle, whose model is P100, whose configuration is high-flow
charlie is a gear pump known to be idle, whose model is G20
delta is a screw pump known to be idle, whose model is S5
echo is a pump known to be idle, whose model is X1
bench-1 is a bench
the test pumps are alpha, bravo and charlie.
the pumps are alpha, bravo and charlie.
the required pumps are alpha, charlie and delta.
