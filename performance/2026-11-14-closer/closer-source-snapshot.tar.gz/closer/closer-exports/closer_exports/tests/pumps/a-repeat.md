# The repeated block (SYNTHETIC): setup and check once per member, in the set order

## Steps

- For each test pump:
  - set up the pump on bench-1
    - takes: 20 s
  - measure the flow of the pump on bench-1
    - takes: 5 s
    - flow: 4 L/min
  - release the pump on bench-1
