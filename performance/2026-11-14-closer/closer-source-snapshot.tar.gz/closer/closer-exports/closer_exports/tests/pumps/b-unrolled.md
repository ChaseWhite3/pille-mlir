# The same procedure unrolled by hand (SYNTHETIC): what the repeated block must agree with

## Steps

- set up alpha on bench-1
  - takes: 20 s
- measure the flow of alpha on bench-1
  - takes: 5 s
  - flow: 4 L/min
- release alpha on bench-1
- set up bravo on bench-1
  - takes: 20 s
- measure the flow of bravo on bench-1
  - takes: 5 s
  - flow: 4 L/min
- release bravo on bench-1
- set up charlie on bench-1
  - takes: 20 s
- measure the flow of charlie on bench-1
  - takes: 5 s
  - flow: 4 L/min
- release charlie on bench-1
