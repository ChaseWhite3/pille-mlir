# Diagnostics (SYNTHETIC): a repeat over no set, a nested repeat, and a check after them resting on their fallback

## Steps

- For each spare pump:
  - set up the pump on bench-1
- For each pump in the test pumps:
  - For each test pump:
    - set up the pump on bench-1
- measure the flow of the pump on bench-1
