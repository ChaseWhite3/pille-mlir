# Pressure (SYNTHETIC): a second quantity measured once per member

## Steps

- For each test pump:
  - set up the pump on bench-1
    - takes: 20 s
  - measure the pressure of the pump on bench-1
    - takes: 5 s
    - pressure: 2 bar
  - release the pump on bench-1
