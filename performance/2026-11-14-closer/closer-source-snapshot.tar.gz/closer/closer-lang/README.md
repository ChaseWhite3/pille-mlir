# closer-lang: Closer's notations, as a Racket package

The `closer` collection: the notations a project of Closer in Mojo writes its language, its words and its
requirements in, written in [Rhombus](https://docs.racket-lang.org/rhombus/). A project keeps its modules in a
`rhombus` folder beside its pages; Closer runs each with `racket` when it is newer than what it last wrote, and reads
what it writes (JSON in the notation wire's shapes, `mojo/ir/schema/notation.capnp`).

| module | what it is |
|---|---|
| `#lang closer/language` | a language in words: kinds, verbs, parts, consequences, units, how names reach across pages, the roles a verb takes from a page's context (`"role" from context`), and qualifiers, a kind's values said before another kind's noun to describe the thing it names (`qualifier("DeviceMode", ~of: "Device", ~describes: "configured mode", ~values: […])`) (`language.rhm`); `reads "../pages"` holds the pages named to the module as it is built, through Closer in Mojo in the same process (`reads.rkt` over `closer/mojo`), a line that does not read a warning at the form; `relation on(Panel, Session) said "on"` declares a relation by name, which a verb's clause names (`"panel" makes on of "session"`, `relations.rhm`) |


| `#lang closer/ccg` | words written as CCG, lowered to the entries of the lexicon (`ccg.rhm`, `lower.rhm`); a clause as the subject (`SG`, `THAT`) with `then …` |
| `#lang closer/requirements` | requirements in EARS form, `R1: when "…" shall "…"`, each with a force: to be shown, `assume`d or `check`ed by a run; one may refine another, `R2: shall "…" refines R1`, and say what it is about by a language's kinds and states bound when the module expands, `about Alarm.SOUNDING -> Alarm.QUIET` (the language module imported); a refinement must keep what it refines (`requirements.rhm`); and say what it means, `means signed_in("p-1")`, a formula applied to the things it names, so a refinement is checked as an implication when the language is built (`mojo/language/entailment.py`) |
| `#lang closer/constraints` | requirements as constraints in an operator notation, with units (`constraints.rhm`) |
| `#lang closer/rules` | propositional rules over things, `∧ ∨ ¬ →`, lowered to the consequences the walk derives (`rules.rhm`); a relation declared by name, its language's or its own (`relation authenticated_through(Session, Panel) said "authenticated through"`), is named in an atom, `panel on session` |

| `#lang closer/meanings` | a language declared by what sentences mean: steps, relations and states with the patterns that say them, their words derived by the reader (`meanings.rhm`) |
| `closer/deduce` | a language deduced from the facts of a Java project's class files (`deduce.rhm`) |
| `closer/ask` | the conversation with Mojo by continuations (`ask.rhm`) |
| `closer/json` | JSON in and out, the representation and nothing else (`json.rkt`) |
| `closer/ccg2lambda` | a sentence's CCG trees, as depccg prints them, given their formulas by the semantic templates (`rules/ccg2lambda-en-event.json`, made of the YAML beside it), node by node, as depccg's ccg2lambda gives them (`ccg2lambda.rhm`, on `nltk_logic.rhm`, NLTK's lambda calculus: its parser, printing, substitution and beta reduction; `racket closer-lang/ccg2lambda.rhm request.json`; held to depccg's formulas by `mojo/reading/ccg2lambda_check.py`) |
| `closer/rewrite` | a ccg2lambda formula read for its atoms and rewritten as the reader rewrites it, the constructions among the passes, before a sentence is lowered (`rewrite.rhm`, `rewrite_text.rkt`; `racket closer-lang/rewrite.rhm request.json`; held to `mojo/reading/read.py` by `mojo/reading/rewrite_check.py`) |
| `closer/sentence` | a sentence lowered to a meaning: the meanings' patterns matched against a parse's terms, each thing held to its kind, the candidate chosen as the reader chooses (`sentence.rhm`; `racket closer-lang/sentence.rhm request.json`, asked by `mojo/reading/lower.py`; `docs/lowering-in-rhombus.md`) |
| `closer/mojo` | Closer in Mojo called in this process over the C ABI: `closer_compile(packs, files)` holds pages to described packs handed as text (`mojo.rhm` over `mojo.rkt`, `build/mojo/libcloser.dylib`; `docs/rhombus-ffi.md`) |

## Where a project's modules are, and working on them

**Found by folder.** The notation build (`mojo/language/notation_build.py`) takes the nearest folder named `rhombus`
beside a project's pages or up to five folders above them, and runs every `.rhm` in it whose sources changed since it
last wrote. What it writes goes to `build/mojo/notation/` beside that folder, which Closer reads as the language. The
`#lang` line says what each module gives. Other languages are composed by a `settings.md` line,
`- languages: ssh, ../other` (a name is a collection, found in `CLOSER_COLLECTIONS` and then the repository's
`languages/`; a path is a folder with its own `rhombus/`), or by `import NAME` in a module.

**An import's requirements.** `mojo/intake/intake.py import` drafts a requirement from each test's objective into
`intake/<doc>/requirements/rhombus/requirements.rhm`, `T1: shall "…"`, the page and the objective as written in a
comment above it; `under.json` beside it says which draft lines each is drafted for. It adds
`- languages: ../requirements` to the drafts' `settings.md`, so the requirements are a language of their own composed
with the project's. They are a draft for a person to correct: an import again keeps the file as edited and only adds
the objectives it does not say yet. A project's own requirements are any `#lang closer/requirements` module in its
`rhombus` folder.

**Working on them.** Edit a module and save. The editor (`tools/vscode-annotate`) has the warm Closer read the
language again from the sources, so the open pages are read with the edit, and a module Racket refuses is a
diagnostic on it. Reviewing an import, the review view watches the project's `rhombus` folder and the import's
`requirements` and reviews again a moment after a change. A line the language does not read has the reader's proposal
as a quick fix, kept in `rhombus/ways.rhm`. From the terminal, `./dev.sh judge PAGES` reads the pages with the
modules as they are, and `./dev.sh round INTAKE PAGES` reviews an import and scores both its drafts and the pages.
After an edit to this package itself, `./dev.sh racket-setup`.

Two things to know while editing. A module Racket refuses leaves what it last built in force, so the pages read as
they did before the edit: the build's problems say so. And a `step` that names no thing (no `"x" is Kind`) is read
as more ways of saying another pack's step of that name, and refused where no pack declares one.

## Install

It needs Racket with Rhombus (`rhombus-lib`); it is built and checked on Racket 9.3. From the repository's root:

    raco pkg install --link --auto closer-lang

A link is the package where it lies: an edit is read the next time a module is expanded (`raco setup --pkgs
closer-lang` compiles it again, which is faster to load). Closer and the repository's checks link it themselves,
into whichever Racket they run (`mojo/language/racket_package.py`, which links it again when the link is to a
checkout that moved), so a module reads the same in a terminal, in DrRacket and in VS Code's Racket extensions.
`raco pkg remove closer-lang` takes it out.

If an editor says `collection not found … closer/language/lang/reader`, the package is not linked into that
editor's Racket: `#lang closer/language` looks for a `reader` submodule of `closer/language` (in `language.rkt`)
and reports the last path it tried. Link it as above, or `python3 mojo/language/racket_package.py`.

## Try it

    racket examples/rhombus-safetynet/rhombus/alarm_language.rhm    # the pack it declares, as JSON
    raco test closer-lang                                            # every module expands

A module is checked when it is expanded: a hole a verb's body does not name, a kind no declaration gives, a relation
no verb names, each a syntax error at the string at fault. `examples/rhombus-safetynet` is the worked example and
its `check.py` the full check.

## A clause as the subject

A category's arguments are noun phrases, `NP[Kind]`, and a sentence taken as one is a clause: a gerund (`SG`,
*silencing the alarm*) or a command (`S`) is a step, a that-clause (`THAT`, *that the alarm is sounding*) or a claim
(`PROP`) is a claim. That is the grammatical function told from the category: the subject of *silencing the alarm
quiets the siren* is a step phrase where a noun phrase would stand. A word that takes one says what follows from
it, `then …`: the step done, or the claim holding, implies the state, relation or claim the rest means (`then
holds` takes the category's other claim as what follows).

    "quiets" : (PROP ∖ SG) / NP[Alarm] => then state Alarm is QUIET
    "means" : (PROP ∖ THAT) / PROP => then holds

The walk judges it as an implication over the facts of its moment, where what each step did is a fact of the path
(`examples/rhombus-safetynet/causes.md`). Two more meanings say what was done: `done OP(args)` for a passive that
states a step done (*the alarm is silenced on the simulator*, a did predicate), and `described OP(arg)` for a
modifier of a noun, before it or after it, naming the thing a step was done to (*the caused alarm*, *the alarm
that was silenced*: the last thing of the kind a line above did that to), `NP[Alarm] ∖ NP[Alarm]`.

A rule says its words as the lexicon's own entries do. A category names a thing by its family and the meaning by
its own kind, `S / NP[Machine] => step start(server :: SafetynetServer)`, the families read from the rest of the
language (`CLOSER_LANGUAGE`, as the notation build gives it); a parameter the words leave unsaid is written so,
`sim :: DeviceSimulator unsaid`, the last thing of its kind said above; and words after a step's last thing close
a clause its phrase opens, `"verify" : CLAUSE["service-running"] / NP[Service]` and `"is running" : S ∖
CLAUSE["service-running"] => closes`.

## Words proposed from English at large

`mojo/reading/propose.py` proposes a `#lang closer/ccg` module for sentences Closer does not read, from depccg's
supertagger and parser with ccg2lambda's semantic templates (`rules/ccg2lambda-en-event.yaml`): each rule beside
the derivation and the lambda term that suggest it, the parser and model named at the top, live where the
language could fill it and a comment with `?` where a person decides. depccg is Python of its own (`pip install
depccg spacy`, `python -m spacy download en_core_web_sm`, `depccg en download`; `CLOSER_DEPCCG` names that
python), and nothing builds or checks against it: `propose_check.py` proposes from what it read once, saved.

## A language declared by meanings

`#lang closer/meanings` is `#lang closer/language` without wordings: a step, a relation or a state is declared with
the patterns that say it, over the term a reader of English at large gives a sentence (depccg with ccg2lambda's
templates, `rules/ccg2lambda-en-event.yaml`: an event with its roles, Subj, Acc, Dat, each thing a noun), and a
verb's effects as any verb's.

    step "stop-alarm":
      said (stop ∨ silence ∨ quieten)[Acc: alarm, on: sim]
      "alarm" is Alarm needs SOUNDING leaves QUIET
      "sim" is DeviceSimulator
      "alarm" ends "raised on" of "sim"
    relation "raised on":
      said raise[Acc: alarm, on: sim]
      "alarm" is Alarm
      "sim" is DeviceSimulator
    state "Alarm" is "SOUNDING":
      said sound[Subj: x]

A pattern is written by its arrows, the event unnamed: the verb, then the roles from its event to the things
(`Subj`, `Acc`, `Dat`, or a preposition); several verbs of one shape in parentheses with `∨`. In an allegory's
terms a step is the composite from its first thing through the event to the others, `Acc˘ ; stop ; on`, and a
state or a modifier is the coreflexive of a range, `ran(sound ; Subj)`; the reader writes each derived word's
shape beside it and, at the module's end, the phrases that share one, so *the silenced alarm* and *the alarm that
was silenced* are seen to be one relation before anyone says so. An atom may be written in full too, `stop(e) ∧
Acc(e) = alarm`. A variable of a pattern no clause names is refused at the meaning.

A `construction` is a shape the reader of English gives a sentence, rewritten to the shape the meanings say,
both sides in the arrows, an arrow to an event written inline:

    construction cause[Acc: alarm] ∧ sound[Subj: alarm, on: sim] ⇒ cause[Acc: alarm, on: sim]
    construction make[AccE: sound[Subj: alarm, on: sim]] ⇒ cause[Acc: alarm, on: sim]

The reader applies it before matching and says so beside the word it gave; a thing named on the right must be
named on the left.

`extend` adds ways of saying a step another module or language declares, its parameters that step's (read from
the rest of the language and the languages composed with it), so a project grows its phrasings in a module of
their own, as a Racket package adds a module to a collection another made:

    extend "stop-alarm":
      said halt[Acc: alarm, on: sim]

The step may be said by its language's name and its own (`extend "ssh.ssh-service-restart":`), where two
languages declare one by the same name; a `step` with only `said` lines does the same, as modules written before
`extend` say it. A module composes another language by its collection's name, `import ssh`, as a project's
`settings.md` may (`- languages: ssh`); a kind of another language is said by its full name where two give one
(`"setting" is "ssh.Setting"`). Two imported languages that both give a noun to different kinds are an error at
the import, settled in its block, the project's own nouns shadowing theirs without one:

    import alpha
    import beta:
      except "knob"
      rename "dial" as "beta dial"

The import is a Rhombus import as well: each noun is a name its language's module exports in a binding space of
its own (`nouns.rhm`), so the refusal of a noun two imports give is the expander's, and `except` and `rename` are
Rhombus's. `docs/STRUCTURE.md` has the namespaces these belong to.

A variable of a pattern is a parameter, an event, or a thing the pattern says by its noun (`directory(x1)`);
one nothing says is refused. Some shapes the reader undoes for every project: a step said as a noun (*the silencing of the
alarm*, which the templates give as a noun equal to the alarm) is the verb's event over the thing; *the siren of
the alarm* and *the alarm's siren* are a thing of another's, `of`; a past participle made a predicate of the thing
(*the moved unit*) is the verb's event with the thing as its object. The module writes the pack Mojo reads, its
verbs with no words, and the meanings beside it (the notation build keeps them as `NAME.meanings.json`); the words
are the reader's, `mojo/reading/read.py`: what depccg read of the project's sentences, matched against the
meanings and written as a `#lang closer/ccg` module the compile takes as words (`examples/rhombus-meanings`).

## What a requirement asserts, and with what force

A requirement says a proposition with a force. Every EARS form is to be **shown**: judged along the plan and over
the worlds, at the strength its kind is answered at. `NAME: assume "…"` is a premise every page starts from, as a
page's Materials say a thing is known to be: the walk starts from it and a guarantee rests on it, and it is never
judged (a page whose own Materials say something of the thing keeps its word). `NAME: check "…"` is what a run
must establish, never judged before one. There is no bare assert: what is meant by saying a thing holds is one of
the three, and they compile to different things.

    A1: assume "the alarm is quiet"
    K1: check "the alarm is quiet"

A compile says each as an assertion of its proposition (`mojo/ir/README.md`), so the same proposition can be
assumed by the requirements, required by a page's claim and checked by a run, and every judgement says what it
rests on (`examples/rhombus-meanings/assumed.md`).
