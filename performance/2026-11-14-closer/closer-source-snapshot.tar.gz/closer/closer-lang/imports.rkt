#lang racket/base
;; The modules of a language a notation imports by its collection's name (import factory), for the import to be a
;; Rhombus import as well: found in what the notation build hands a module of the rest of the project's language
;; (CLOSER_LANGUAGE, NAME.facts.json: each pack with the path it was built to, LANGUAGE/build/mojo/notation/X.json,
;; whose source is LANGUAGE/rhombus/X.rhm). Each as a list: the module's path, then the nouns its kinds give.
;; Nothing where no build handed anything (a module compiled by itself): then only Closer composes, as before.
;; Nor a module with a compiled file older than the notation's nouns (compiled before a kind's nouns were bindings,
;; and loaded as it is by a racket that is not asked to keep compiled files up to date): it gives no noun to import.
(require json racket/string racket/list racket/runtime-path)
(provide language-modules)

(define-runtime-path nouns-source "nouns.rhm")
(define (stale? source)
  (define-values (dir name must-be-dir?) (split-path source))
  (define zo (build-path dir "compiled" (path-add-extension (path-replace-extension name #"_rhm") #".zo")))
  (and (file-exists? zo)
       (< (file-or-directory-modify-seconds zo) (file-or-directory-modify-seconds nouns-source))))

(define (language-modules name)
  (define facts (getenv "CLOSER_LANGUAGE"))
  (cond
    [(or (not facts) (string=? facts "") (not (file-exists? facts))) '()]
    [else
     (define packs (hash-ref (call-with-input-file facts read-json) 'packs '()))
     (define shape (pregexp (string-append "^(.*/" (regexp-quote name) ")/build/mojo/notation/(?:composed/)?([^/]+)\\.json$")))
     (remove-duplicates
      (for*/list ([p (in-list packs)]
                  [path (in-value (hash-ref p 'path #f))]
                  #:when (string? path)
                  [m (in-value (regexp-match shape path))]
                  #:when m
                  [source (in-value (string-append (cadr m) "/rhombus/" (caddr m) ".rhm"))]
                  #:when (and (file-exists? source) (not (stale? source))))
        (cons source
              (remove-duplicates
               (append* (for/list ([k (in-list (hash-ref p 'kinds '()))])
                          (filter (lambda (w) (not (string=? w ""))) (string-split (hash-ref k 'nouns "") "|")))))))
      #:key car)]))
