#lang info
;; The `closer` collection: Closer's notations as a Racket package. `#lang closer/ccg` writes words as CCG
;; (ccg.rkt, ccg.rhm, lower.rhm); closer/language declares a language in words (language.rhm); closer/deduce deduces
;; one from the facts of Java's class files (deduce.rhm); closer/rules writes propositional rules lowered to
;; consequences (rules.rhm); closer/meanings declares a language by what sentences mean, its words derived by the
;; reader (meanings.rhm); closer/ask is the conversation with Mojo by continuations
;; (ask.rhm); closer/json converts JSON. Installed from the repository's root with
;; `raco pkg install --link --auto closer-lang`; Closer and the checks link it themselves (mojo/language/racket_package.py).
(define collection "closer")
(define deps '("base" "rhombus-lib" "shrubbery-lib"))
(define pkg-desc "Closer's notations: a language in words, words as CCG, and the conversation with Mojo")
(define version "0.1")
(define license 'MIT)
(define pkg-authors '("Chase White"))
