#lang racket/base
;; Representation conversion only. Domain elaboration lives in plan.rhm; the conversation with Mojo in ask.rhm.
(require json racket/treelist)
(provide read_json emit_json write_json_file arguments argument read_json_line read_request read_file getenv_of parse_json json_text)
(define (getenv_of name) (or (getenv name) ""))
(define (from-json x)
  (cond [(hash? x) (for/hashalw ([(k v) (in-hash x)]) (values (string->immutable-string (symbol->string k)) (from-json v)))]
        [(list? x) (list->treelist (map from-json x))]
        [(string? x) (string->immutable-string x)]
        [else x]))
(define (to-json x)
  (cond [(hash? x) (for/hash ([(k v) (in-hash x)]) (values (string->symbol k) (to-json v)))]
        [(treelist? x) (map to-json (treelist->list x))]
        [else x]))
(define (read_json path) (call-with-input-file path (lambda (in) (from-json (read-json in)))))
(define (emit_json x) (write-json (to-json x)) (newline) (flush-output))
;; one JSON value from standard input, Mojo's answer to a question; the conversation over when none comes
(define (read_json_line)
  (define v (read-json))
  (when (eof-object? v) (error 'ask "Mojo ended the conversation before answering"))
  (from-json v))
;; a file's text, for a notation that reads another file when it is expanded (closer/constraints, its units)
(define (read_file path) (string->immutable-string (call-with-input-file path (lambda (in) (let ([s (read-string 10000000 in)]) (if (eof-object? s) "" s))))))
;; the next request from Mojo, or #f when Mojo has closed the conversation
(define (read_request)
  (define v (read-json))
  (if (eof-object? v) #f (from-json v)))
(define (argument n) (string->immutable-string (vector-ref (current-command-line-arguments) n)))
;; JSON written to a file, for a program whose answer is a file (closer/deduce, the pack it deduces)
(define (write_json_file path x) (call-with-output-file path #:exists 'truncate (lambda (out) (write-json (to-json x) out) (newline out))))
;; the program's arguments, all of them
(define (arguments) (map string->immutable-string (vector->list (current-command-line-arguments))))
;; JSON as text and back, for a value carried through syntax as a string literal (a formula's tree)
(define (parse_json s) (from-json (string->jsexpr s)))
(define (json_text x) (string->immutable-string (jsexpr->string (to-json x))))
