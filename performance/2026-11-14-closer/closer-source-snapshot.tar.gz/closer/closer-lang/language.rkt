#lang racket/base
;; `#lang closer/language`: the reader parses the module body as shrubbery notation and hands it to closer/language.rhm,
;; the language, as rhombus's own reader does for rhombus.
(module reader syntax/module-reader
  #:language '(lib "closer/language.rhm")
  #:read (lambda (in) (list (syntax->datum (parse-all in))))
  #:read-syntax (lambda (src in) (list (parse-all in #:source src)))
  #:info get-info-proc
  #:whole-body-readers? #t
  (require shrubbery/parse
           (only-in (submod rhombus/private/core reader) get-info-proc)))

(module configure-runtime racket/base
  (require rhombus/runtime-config))

(module configure-expand racket/base
  (require rhombus/expand-config)
  (provide enter-parameterization
           exit-parameterization))
