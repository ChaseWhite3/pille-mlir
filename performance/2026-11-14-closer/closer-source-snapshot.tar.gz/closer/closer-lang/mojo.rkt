#lang racket/base
;; Closer in Mojo called over the C ABI: build/mojo/libcloser.dylib (mojo/closer_lib.mojo, built by mojo/build.sh)
;; loaded into this Racket, and its closer_compile asked to compile pages under described packs handed as text, with no
;; file and no process between the notation and Closer (docs/rhombus-ffi.md). A notation in Rhombus reaches it through
;; mojo.rhm. The library is loaded once, on the first call, from the checkout CLOSER_HOME names (else the one this
;; file is in); the Mojo runtime and the Python it calls come up inside this process then.
(require ffi/unsafe json racket/runtime-path racket/sequence racket/path racket/string)
(provide closer-home closer-library closer-compile closer-recipe-problems)

(define-runtime-path here ".")

;; the checkout: CLOSER_HOME, else above closer-lang
(define (closer-home)
  (or (getenv "CLOSER_HOME") (path->string (simplify-path (build-path here 'up)))))

(define library #f)
(define compile-function #f)

;; the library's closer_compile, loaded once: (request-bytes request-length buffer capacity) -> length written, or
;; the length needed, negative
(define (closer-library)
  (unless compile-function
    (set! library (ffi-lib (build-path (closer-home) "build" "mojo" "libcloser")))
    (set! compile-function (get-ffi-obj "closer_compile" library (_fun _bytes _int _bytes _int -> _int))))
  compile-function)

;; packs: described packs as JSON text, each as its notation writes it; files: each (name . text), (list name text),
;; or a hash with 'name and 'text, settings.md among them; requirements: requirements as JSON text, as their
;; notation writes them; under: the pages each requirement is under, as under.json says them ({ID: {lines: [[PAGE …] …]}});
;; only: the names of the pages to compile among the files (none: all). The answer is the
;; procedure value `closer compile` prints, as a jsexpr, or (hasheq 'error …).
(define (closer-compile packs files #:requirements [requirements '()] #:under [under (hasheq)] #:only [only '()])
  (define (file-of f)
    (cond [(hash? f) (hasheq 'name (hash-ref f 'name) 'text (hash-ref f 'text))]
          [(pair? f) (let ([rest (cdr f)])
                       (hasheq 'name (car f) 'text (if (pair? rest) (car rest) rest)))]
          [else (let ([l (sequence->list f)]) (hasheq 'name (car l) 'text (cadr l)))]))
  (define request
    (jsexpr->bytes (hasheq 'home (closer-home)
                           'packs (sequence->list packs)
                           'requirements (sequence->list requirements)
                           'under under
                           'files (map file-of (sequence->list files))
                           'only (sequence->list only))))
  (define call (closer-library))
  (let again ([capacity (* 4 1024 1024)])
    (define buffer (make-bytes capacity))
    (define n (call request (bytes-length request) buffer capacity))
    (if (< n 0)
        (again (- n))
        (bytes->jsexpr (subbytes buffer 0 n)))))

;; What a recipe says that no recipe does, asked of Closer's own check (closer_lib.mojo's closer_recipe_problems,
;; recipes.mojo's recipe_problems): the lines of a step's does: and the names of its parameters, each a sequence of
;; strings; the problems, a list of strings, empty for none. The notation asks it as a module is expanded
;; (language.rhm's recipe_held), so it must never be why a module does not build: where the library is not built,
;; or was built before it had the check, nothing is asked and the answer is empty.
(define recipe-function 'unasked)
(define (closer-recipe-problems does names)
  (when (eq? recipe-function 'unasked)
    (set! recipe-function
          (with-handlers ([exn:fail? (lambda (e) #f)])
            (get-ffi-obj "closer_recipe_problems" (ffi-lib (build-path (closer-home) "build" "mojo" "libcloser"))
                         (_fun _bytes _int _bytes _int _bytes _int -> _int)))))
  (cond
    [(not recipe-function) '()]
    [else
     (define d (string->bytes/utf-8 (string-join (sequence->list does) "\n")))
     (define n (string->bytes/utf-8 (string-join (sequence->list names) "\n")))
     (let ask ([capacity 1024])
       (define buffer (make-bytes capacity))
       (define wrote (recipe-function d (bytes-length d) n (bytes-length n) buffer capacity))
       (cond [(zero? wrote) '()]
             [(negative? wrote) (ask (- wrote))]
             [else (string-split (bytes->string/utf-8 (subbytes buffer 0 wrote)) "\n")]))]))
