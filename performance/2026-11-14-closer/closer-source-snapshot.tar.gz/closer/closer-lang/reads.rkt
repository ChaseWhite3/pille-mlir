#lang racket/base
;; A language module's `reads "PATH"`: the pages the module should read, held to the module as it is now, through
;; Closer in Mojo loaded into this process (mojo.rkt) with the module's own described pack handed as text and the
;; project's other packs as last built. Each line of a page the language does not read is a warning at the form, in
;; the module's problems (the notation build shows them at the line). PATH is a folder of pages or one page; a page's
;; folder is handed whole (its Materials and settings), and that page alone compiled.
(require racket/path racket/list racket/string racket/treelist json "mojo.rkt")
(provide reads-problems)

;; a Rhombus value (maps with string keys, lists as treelists) as a jsexpr
(define (jsexpr-of x)
  (cond [(hash? x) (for/hasheq ([(k v) (in-hash x)]) (values (if (symbol? k) k (string->symbol k)) (jsexpr-of v)))]
        [(treelist? x) (map jsexpr-of (treelist->list x))]
        [(list? x) (map jsexpr-of x)]
        [else x]))

(define (problem file line column message)
  (hash "file" (string->immutable-string file) "line" line "column" column
        "message" (string->immutable-string message) "severity" "warning"))

(define (pages-of folder)
  (for/list ([f (sort (map path->string (directory-list folder)) string<?)]
             #:when (string-suffix? f ".md"))
    (cons f (call-with-input-file (build-path folder f) (lambda (in) (let ([s (read-string 100000000 in)]) (if (eof-object? s) "" s)))))))

;; described: the module's pack as described; asks: each (treelist full-path line column module-file); others: the
;; other packs' described files, as the notation build lists them. A treelist of problems, each a map.
(define (reads-problems described asks others)
  (define own (jsexpr-of described))
  (define pack-text (jsexpr->string (for/hasheq ([(k v) (in-hash own)] #:unless (memq k '(built problems))) (values k v))))
  (define packs (cons pack-text (for/list ([p (treelist->list others)] #:when (file-exists? p)) (string->immutable-string p))))
  (list->treelist
   (for*/list ([ask (treelist->list asks)]
               [p (ask-one packs (treelist-ref ask 0) (treelist-ref ask 1) (treelist-ref ask 2) (treelist-ref ask 3))])
     p)))

(define (ask-one packs path line column module-file)
  (define at (lambda (message) (problem module-file line column message)))
  (with-handlers ([exn:fail? (lambda (e) (list (at (string-append "the pages were not held to this module: " (exn-message e)
                                                                   " (build/mojo/libcloser.dylib is built by ./mojo/build.sh)"))))])
    (define folder (if (directory-exists? path) path (path->string (path-only path))))
    (define only (if (directory-exists? path) '() (list (path->string (file-name-from-path path)))))
    (cond
      [(not (directory-exists? folder)) (list (at (string-append "no pages at " path)))]
      [(and (pair? only) (not (file-exists? path))) (list (at (string-append "no page at " path)))]
      [else
       (define answer (closer-compile packs (pages-of folder) #:only only))
       (cond
         [(hash-ref answer 'error #f) => (lambda (e) (list (at (string-append "Closer could not read " path ": " e))))]
         [else
          (for/list ([issue (hash-ref answer 'issues '())]
                     #:when (member (hash-ref issue 'kind "") '("language" "syntax")))
            (at (format "~a line ~a does not read under this module: ~a" (hash-ref issue 'file "") (hash-ref issue 'line 0) (hash-ref issue 'message ""))))])])))
