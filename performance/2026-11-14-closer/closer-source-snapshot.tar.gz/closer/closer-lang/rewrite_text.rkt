#lang racket/base
;; The text the term rewrites read (closer-lang/rewrite.rhm): ccg2lambda's formula as tokens, and the few searches of a
;; formula's or a line's words they make, each as mojo/reading/read.py makes it with Python's re. Representation and
;; regular expressions only; the rewrites are in rewrite.rhm.
(require racket/string racket/treelist)
(provide formula_tokens find_all search_end starts_matching python_split is_digits strip_trailing lstrip
         matches_whole remove_all first_groups)

;; the formula's tokens, as read.py's tokens: whitespace, then the first of -> | _ and anything but a delimiter | a
;; letter and letters, digits, _ or ' | digits | one of ( ) . , & | = \ - (a predicate is _ and then anything but a
;; delimiter, since the templates make one of any word: _{, _10, _pr-high); scanned by hand, character by character,
;; as a regular expression matched from each offset in turn reads the rest of the string again each time. A formula
;; with a character none begins with, or ending in whitespace, is refused, as there
(define (delimiter? c) (or (char-whitespace? c) (memv c '(#\( #\) #\, #\& #\| #\=))))
(define (ascii-letter? c) (or (char<=? #\a c #\z) (char<=? #\A c #\Z)))
(define (ascii-digit? c) (char<=? #\0 c #\9))
(define (formula_tokens text)
  (define n (string-length text))
  (define (refuse at) (error 'ccg2lambda (format "term: cannot read at ~a" (substring text at (min n (+ at 20))))))
  (let loop ([at 0] [out '()])
    (if (>= at n)
        (list->treelist (reverse out))
        (let* ([start (let skip ([i at]) (if (and (< i n) (char-whitespace? (string-ref text i))) (skip (add1 i)) i))])
          (when (>= start n) (refuse at))
          (define c (string-ref text start))
          (define (upto pred i) (if (and (< i n) (pred (string-ref text i))) (upto pred (add1 i)) i))
          (define end
            (cond [(and (char=? c #\-) (< (add1 start) n) (char=? (string-ref text (add1 start)) #\>)) (+ start 2)]
                  [(char=? c #\_) (upto (lambda (d) (not (delimiter? d))) (add1 start))]
                  [(ascii-letter? c) (upto (lambda (d) (or (ascii-letter? d) (ascii-digit? d) (char=? d #\_) (char=? d #\'))) (add1 start))]
                  [(ascii-digit? c) (upto ascii-digit? (add1 start))]
                  [(memv c '(#\( #\) #\. #\, #\& #\| #\= #\\ #\-)) (add1 start)]
                  [else (refuse at)]))
          (loop end (cons (string->immutable-string (substring text start end)) out))))))

;; a pattern compiled once, whatever number of times it is asked for
(define compiled (make-hash))
(define (rx pattern) (hash-ref! compiled pattern (lambda () (pregexp pattern))))
(define (rx-at-start pattern) (hash-ref! compiled (cons 'start pattern) (lambda () (pregexp (string-append "^(?:" pattern ")")))))

;; every match of a pattern's first group (its whole, where it has none) in the text, in order: Python's re.findall
(define (find_all pattern text)
  (list->treelist
   (for/list ([m (in-list (regexp-match* (rx pattern) text #:match-select values))])
     (string->immutable-string (if (and (pair? (cdr m)) (cadr m)) (cadr m) (car m))))))

;; where the first match of the pattern ends, or #f: Python's re.search(…).end()
(define (search_end pattern text)
  (define m (regexp-match-positions (rx pattern) text))
  (and m (cdar m)))

;; whether the text begins with a match of the pattern: Python's re.match
(define (starts_matching pattern text)
  (and (regexp-match-positions (rx-at-start pattern) text) #t))

;; the words between runs of whitespace, none empty: Python's str.split()
(define (python_split text)
  (list->treelist (map string->immutable-string (string-split text))))

;; Python's str.isdigit: not empty, and every character a digit
(define (is_digits s)
  (and (positive? (string-length s)) (for/and ([c (in-string s)]) (char-numeric? c))))

;; Python's str.rstrip(chars): every one of the characters off the end, as many as there are
(define (strip_trailing s chars)
  (let loop ([n (string-length s)])
    (if (and (positive? n) (for/or ([c (in-string chars)]) (char=? c (string-ref s (sub1 n)))))
        (loop (sub1 n))
        (string->immutable-string (substring s 0 n)))))

;; Python's str.lstrip(): the whitespace off the start
(define (lstrip s) (string->immutable-string (string-trim s #:right? #f)))

;; whether the whole text matches the pattern: Python's re.fullmatch
(define (matches_whole pattern text)
  (and (regexp-match? (hash-ref! compiled (cons 'whole pattern) (lambda () (pregexp (string-append "^(?:" pattern ")$")))) text) #t))

;; the text with every match of the pattern taken out: Python's re.sub(pattern, '', text)
(define (remove_all pattern text)
  (string->immutable-string (regexp-replace* (rx pattern) text "")))

;; every match's first group, "" where the group took part in none: Python's re.findall with one group
(define (first_groups pattern text)
  (list->treelist
   (for/list ([m (in-list (regexp-match* (rx pattern) text #:match-select values))])
     (string->immutable-string (or (and (pair? (cdr m)) (cadr m)) "")))))
