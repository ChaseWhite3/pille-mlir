#lang racket/base
;; A notation's macro that reads a binding at expansion, as requirements' about reads a kind's bridge, leaves no
;; reference to it in what it expands to. with_uses marks an expression as having used those identifiers (Racket's
;; 'disappeared-use), so check-syntax, and the editor's hover, definition and highlighting through it, see the use
;; and the import that brought it. The mark goes on the parsed expression itself, inside Rhombus's parsed wrapper,
;; where the expander keeps it.
(require racket/treelist)
(provide with_uses)

(define (with_uses stx ids)
  (define uses
    (for/list ([i (in-list (if (treelist? ids) (treelist->list ids) ids))]
               #:when (identifier? i))
      (syntax-local-introduce (in_its_space i))))
  (define (mark e)
    (define before (syntax-property e 'disappeared-use))
    (syntax-property e 'disappeared-use (if before (cons uses before) uses)))
  (syntax-case stx ()
    [(tag kw e)
     (and (identifier? #'tag) (eq? (syntax-e #'tag) 'parsed) (keyword? (syntax-e #'kw)))
     (datum->syntax stx (list #'tag #'kw (mark #'e)) stx stx)]
    [_ (mark stx)]))

;; A name used as it is bound: a kind is an annotation and a namespace, which Rhombus binds each in its own space,
;; both binders at the kind's declaration. The annotation is declared after the namespace, and an editor keeps one
;; binding per place, the later one, so a kind's name is taken in the annotation space where it is bound there, else
;; in the namespace space, else as it is
(define namespace-space (make-interned-syntax-introducer 'rhombus/namespace))
(define annot-space (make-interned-syntax-introducer 'rhombus/annot))
(define (in_its_space id)
  (define in-namespace (namespace-space id 'add))
  (define in-annot (annot-space id 'add))
  (cond
    [(identifier-binding in-annot) in-annot]
    [(identifier-binding in-namespace) in-namespace]
    [else id]))

;; A binder a notation makes from what was written, as kind("Panel", …) makes Panel from its string, has neither
;; the source's place nor counts as its text, and check-syntax reports no definition for it. as_original gives the
;; binder the place of what it was made from and marks it as standing for that text (Racket's
;; 'original-for-check-syntax), so a use's definition goes to where the kind was declared.
(provide as_original)
(define (as_original id written)
  (syntax-property (datum->syntax id (syntax-e id) written id) 'original-for-check-syntax #t))

;; A kind's states are members of the kind's namespace (closer/language, kind_namespace): each a definition, so a use
;; is a reference an editor follows, and the kind's facts carry each state's binder (quoted) so a notation that reads
;; a state at expansion, as requirements' about does, records a use of it where it was written (use_at).
(require (for-syntax racket/base))
(provide quoted use_at state_value)
;; the binder, as an expression whose value at expansion is the identifier itself
(define (quoted id) #`(parsed #:rhombus/expr (quote-syntax #,id)))
;; the binder's binding at the place the state was written, standing for that text
(define (use_at binder written)
  (syntax-property (datum->syntax binder (syntax-e binder) written written) 'original-for-check-syntax #t))
;; a state's value, a map of its kind and name. A Racket function, so the definition it makes carries no Rhombus
;; static information beside it: an editor keeps one binding per place, and a second at the state would hide it
(define (state_value kind state) (hash "kind" kind "state" state))
