# Row kinds

<!-- Closer's one definition of what a row of a test report is. Every page's rows are
     read by these kinds, numbered by these rules, and filled by these cells; a pack's
     settings.md says only what "Packs may say" lists, and no pack defines a kind of its
     own unless this file lets it. closer.procedure.rows reads this file; docs/claims.md
     and docs/result-model.md say how the rows come out. -->

## Packs may say

- template, report type, product, pages, step numbers, first test, materials (no longer read: a page of namings goes first in pages:, and has no rows)
- row kinds of their own: no

## How a page's lines become rows

- a page is one test: its title line is the test, numbered {test}, its place in pages: counted from the first test's number (first test: 4, else 1)
- a block of lines a blank line ends is one row, unless the lines below say otherwise
- a report the settings lay out (## The report with its sections, ## Rows with its kinds) numbers its rows by that layout, a step a row, and the record follows it, so the number the editor shows at a line is the number rows.md keeps for it
- a quote (>) is an objective
- a heading ## Prerequisites or ## Setup makes the list items under it that part; ## Steps, steps again; rows.md may say a step's row is setup, prerequisites or a step wherever its step is (· kind: setup on the row's line), the step running where it is and the rows numbered by it
- a list item is a step: its nested values (key: value) and its command ($) are its own
- a value nested under a step whose key repeats (- privilege: …, twice or more) is a member of the step, one a line
- in a dialogue under a step, each prompt (?), reply (>) and line shown (!) is a row; another line shown (&) is part of the row above it, its words stacked under that row's; a full stop (.), the dialogue's last line, is a row that checks the command ended (Verify that the command exits, or its own words: . the installer exits); a dialogue line indented under another is a member of it, and a reply under a prompt that is a member answers it: one member, as a TR tabulates a question and its result
- a sentence indented under a step is a member of it: a step inside the world the step opens
- prose after the first row is a note, or, under ## Prerequisites or ## Setup, that part's; prose before the first row names things and is no row
- a Materials or Report section is no row
- numbers are counted, never written: a number typed first on a line is an error at the line
- a cell's words are said here, once for every pack: <settings:name> in them is that setting as the row ran with it (its build as read from the machine, or as settings.md said it then), else as settings.md says it now: build says Build <settings:build> words every row's build cell so

## test

- is: the page's title
- numbered: as the test

## objective

- is: a quote
- numbered: no
- cells: words across the whole row
- never run

## prerequisites

- is: a list item under ## Prerequisites
- numbered: no
- cells: number, words, build, result
- when it passes: result says Pass, build says <settings:build>
- when it fails: result says Fail, build says <settings:build>
- until it runs: result and build are empty

## setup

- is: a list item under ## Setup
- numbered: no
- cells: number, words, build, result
- when it passes: result says Pass, build says <settings:build>
- when it fails: result says Fail, build says <settings:build>
- until it runs: result and build are empty

## step

- is: a list item under ## Steps, or under no part heading
- numbered: yes
- cells: number, words, build, result
- when it passes: result says Pass, build says <settings:build>
- when it fails: result says Fail, build says <settings:build>
- until it runs: result and build are empty

## prompt

- is: what the machine asks (?) in a dialogue
- numbered: yes
- cells: number, words, build, result
- when it passes: result says Pass, build says <settings:build>
- when it fails: result says Fail, build says <settings:build>
- until it runs: result and build are empty

## reply

- is: what is typed (>) in a dialogue
- numbered: yes
- cells: number, words, build, result
- when it passes: result says Pass, build says <settings:build>
- when it fails: result says Fail, build says <settings:build>
- until it runs: result and build are empty

## shown

- is: a line the machine shows (!) in a dialogue, with any (&) lines under it; or the command ending (.)
- numbered: yes
- cells: number, words, build, result
- when it passes: result says Pass, build says <settings:build>
- when it fails: result says Fail, build says <settings:build>
- until it runs: result and build are empty

## heading

- is: a line of words ending in a colon in a dialogue, over the prompts indented under it
- numbered: yes
- cells: number, words, build, result
- when it passes: result says Pass, build says <settings:build>
- when it fails: result says Fail, build says <settings:build>
- until it runs: result and build are empty

## member

- is: a value a step repeats, or a dialogue line indented under another
- numbered: under its row
- cells: number, words, build, result
- when it passes: result says Pass, build says <settings:build>
- when it fails: result says Fail, build says <settings:build>
- until it runs: result and build are empty

## note

- is: prose after the first row
- numbered: yes
- cells: number, words, build, result
- never run
