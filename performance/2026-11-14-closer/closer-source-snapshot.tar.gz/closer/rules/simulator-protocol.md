# Simulator protocol

<!-- Closer's one definition of how a device simulator is launched and spoken to, for every pack: whoever runs
     Closer says it here, once; a simulator-protocol.md in Closer's state folder (beside users.edn) is read in place
     of this one, and read again when it changes. A simulator is a thing a page's Materials name, read from the
     team's reference file by a data source (- program:, - arguments:, - port:, and any other column a template
     here needs); a pack's verb sends one of the messages below by name. A {hole} is filled from the values the
     verb gives, else from the simulator's own lines, else {simulator} is its name; a value with a space in it
     is quoted, as it would be typed at a terminal. A column of the reference file read as <quantity> range
     (spo2 range: SpO2 range) is what the simulator is rated for in that quantity: a stub that assumes a measure past
     it is refused, since the simulator could not produce it. closer.run.simulators reads this file. -->

## Launch

- command: python {program} {arguments} {port}
- with the debugger: python -m debugpy --listen 127.0.0.1:{debug port} {program} {arguments} {port}
- ready when: port {port} accepts a connection
- ready within: 15 s
- stop: terminate, then kill after 5 s

## Send

- request: POST http://127.0.0.1:{port}/
- content type: text/plain
- ok when: ^\s*(OK|ok|200)\b|^\s*$
- error when: ^\s*(ERR|ERROR|error)\b[:\s]*(?<reason>.*)$

## Readings

<!-- What a reply says, as named groups; each becomes a reading of the reply by its group's name. -->

- (?<key>[A-Za-z][A-Za-z0-9_.:-]*)\s*=\s*"?(?<value>[^"\s]*)"?

## Messages

<!-- Each a name a verb says, and the text sent: POCAlarm=SpO2High POCValue=100, as typed. A key the device
     says differently is a column of the reference file (alarm key, value key) rather than a change here. -->

- raise: {alarm key}={alarm} {value key}={value}
- clear: {alarm key}={alarm} {value key}=0
- set: {key}={value}
