# Units

<!-- The units a measure is in, as a procedure says one: 5 s, 0 °C, 2.5 V, 30 %. The language's own units are
     anote.Measure's default table, and these lines add to them: one unit a line, the words it goes by separated
     by commas, then its canonical spelling, its dimension in parentheses, and its factor to the dimension's base
     unit. Whoever runs Closer adds their own here, once, for every pack: a units.md in Closer's state folder
     (beside users.edn) is read in place of this one, and read again when it changes. A word said here for a unit
     the default table has wins. Counts (5 times, 8 attempts) are not measures and do not belong here.
     closer.units reads this file. -->

## Units

- °c, degc, deg c, celsius, degrees celsius: °C (temperature) 1
- l, liter, liters, litre, litres: L (volume) 1
- ml, milliliter, milliliters, millilitre, millilitres: mL (volume) 0.001
- lpm, liters per minute, litres per minute: L/min (flow) 1
- ml/min, milliliters per minute, millilitres per minute: mL/min (flow) 0.001
- kpa, kilopascal, kilopascals: kPa (pressure) 1
- bar, bars: bar (pressure) 100
- mbar, millibar, millibars: mbar (pressure) 0.1
